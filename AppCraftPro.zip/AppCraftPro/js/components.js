// Components.js - Defines component templates and rendering logic

// Component Templates
const componentTemplates = {
    container: {
        render: function(data = {}) {
            const container = document.createElement('div');
            container.id = data.id || 'container_' + Date.now();
            container.classList.add('canvas-component', 'canvas-container-component');
            container.dataset.componentType = 'container';
            
            // Apply properties
            applyComponentProperties(container, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Container';
            container.appendChild(handle);
            
            // Add content div
            const content = document.createElement('div');
            content.classList.add('component-content');
            
            // Add children if any
            if (data.children && data.children.length > 0) {
                data.children.forEach(child => {
                    const childComponent = renderComponent(child);
                    if (childComponent) {
                        content.appendChild(childComponent);
                    }
                });
            } else {
                content.textContent = 'Container';
            }
            
            container.appendChild(content);
            return container;
        }
    },
    
    row: {
        render: function(data = {}) {
            const row = document.createElement('div');
            row.id = data.id || 'row_' + Date.now();
            row.classList.add('canvas-component', 'canvas-row-component');
            row.dataset.componentType = 'row';
            
            // Apply properties
            applyComponentProperties(row, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Row';
            row.appendChild(handle);
            
            // Add content div
            const content = document.createElement('div');
            content.classList.add('component-content');
            content.style.display = 'flex';
            content.style.flexWrap = 'wrap';
            
            // Add children if any
            if (data.children && data.children.length > 0) {
                data.children.forEach(child => {
                    const childComponent = renderComponent(child);
                    if (childComponent) {
                        content.appendChild(childComponent);
                    }
                });
            } else {
                content.textContent = 'Row';
            }
            
            row.appendChild(content);
            return row;
        }
    },
    
    button: {
        render: function(data = {}) {
            const button = document.createElement('div');
            button.id = data.id || 'button_' + Date.now();
            button.classList.add('canvas-component', 'canvas-button-component');
            button.dataset.componentType = 'button';
            
            // Apply properties
            applyComponentProperties(button, data.properties);
            
            // Default button properties
            if (!button.style.backgroundColor) {
                button.style.backgroundColor = '#4285f4';
            }
            if (!button.style.color) {
                button.style.color = 'white';
            }
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Button';
            button.appendChild(handle);
            
            // Add content div
            const content = document.createElement('div');
            content.classList.add('component-content');
            content.textContent = data.properties?.content || 'Button';
            
            button.appendChild(content);
            return button;
        }
    },
    
    text: {
        render: function(data = {}) {
            const text = document.createElement('div');
            text.id = data.id || 'text_' + Date.now();
            text.classList.add('canvas-component', 'canvas-text-component');
            text.dataset.componentType = 'text';
            
            // Apply properties
            applyComponentProperties(text, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Text';
            text.appendChild(handle);
            
            // Add content div
            const content = document.createElement('div');
            content.classList.add('component-content');
            content.textContent = data.properties?.content || 'Text Content';
            
            text.appendChild(content);
            return text;
        }
    },
    
    image: {
        render: function(data = {}) {
            const image = document.createElement('div');
            image.id = data.id || 'image_' + Date.now();
            image.classList.add('canvas-component', 'canvas-image-component');
            image.dataset.componentType = 'image';
            
            // Apply properties
            applyComponentProperties(image, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Image';
            image.appendChild(handle);
            
            // Add content div
            const content = document.createElement('div');
            content.classList.add('component-content', 'image-placeholder');
            
            // If we have an image URL, display it
            if (data.properties && data.properties.src) {
                const imgElement = document.createElement('img');
                imgElement.src = data.properties.src;
                imgElement.alt = data.properties.alt || 'Image';
                imgElement.style.maxWidth = '100%';
                content.innerHTML = '';
                content.appendChild(imgElement);
            } else {
                // Otherwise show placeholder
                const icon = document.createElement('i');
                icon.dataset.feather = 'image';
                content.appendChild(icon);
                
                const text = document.createElement('p');
                text.textContent = 'Image';
                content.appendChild(text);
            }
            
            image.appendChild(content);
            
            // Initialize feather icons
            setTimeout(() => {
                if (window.feather) {
                    feather.replace();
                }
            }, 0);
            
            return image;
        }
    },
    
    input: {
        render: function(data = {}) {
            const inputContainer = document.createElement('div');
            inputContainer.id = data.id || 'input_' + Date.now();
            inputContainer.classList.add('canvas-component', 'canvas-input-component-container');
            inputContainer.dataset.componentType = 'input';
            
            // Apply properties
            applyComponentProperties(inputContainer, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Input';
            inputContainer.appendChild(handle);
            
            // Add label if specified
            if (data.properties && data.properties.label) {
                const label = document.createElement('label');
                label.textContent = data.properties.label;
                label.classList.add('component-label');
                label.htmlFor = inputContainer.id + '_input';
                inputContainer.appendChild(label);
            }
            
            // Add the input element
            const input = document.createElement('input');
            input.id = inputContainer.id + '_input';
            input.type = (data.properties && data.properties.inputType) || 'text';
            input.placeholder = (data.properties && data.properties.placeholder) || 'Input field';
            input.classList.add('component-content', 'canvas-input-component');
            
            if (data.properties && data.properties.required) {
                input.required = true;
            }
            
            inputContainer.appendChild(input);
            return inputContainer;
        }
    },
    
    list: {
        render: function(data = {}) {
            const list = document.createElement('div');
            list.id = data.id || 'list_' + Date.now();
            list.classList.add('canvas-component', 'canvas-list-component');
            list.dataset.componentType = 'list';
            
            // Apply properties
            applyComponentProperties(list, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'List';
            list.appendChild(handle);
            
            // Add content container
            const content = document.createElement('div');
            content.classList.add('component-content');
            
            // Add list items
            const items = (data.properties && data.properties.items) || [
                'List Item 1',
                'List Item 2',
                'List Item 3'
            ];
            
            items.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.classList.add('canvas-list-item');
                itemElement.textContent = item;
                content.appendChild(itemElement);
            });
            
            list.appendChild(content);
            return list;
        }
    },
    
    navigation: {
        render: function(data = {}) {
            const nav = document.createElement('div');
            nav.id = data.id || 'navigation_' + Date.now();
            nav.classList.add('canvas-component', 'canvas-navigation-component');
            nav.dataset.componentType = 'navigation';
            
            // Apply properties
            applyComponentProperties(nav, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Navigation';
            nav.appendChild(handle);
            
            // Add content container
            const content = document.createElement('div');
            content.classList.add('component-content');
            content.style.display = 'flex';
            
            // Add navigation items
            const items = (data.properties && data.properties.items) || [
                { label: 'Home', screen: 'mainScreen' },
                { label: 'About', screen: '' },
                { label: 'Contact', screen: '' }
            ];
            
            items.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.classList.add('canvas-nav-item');
                itemElement.textContent = item.label;
                itemElement.dataset.screen = item.screen;
                content.appendChild(itemElement);
            });
            
            nav.appendChild(content);
            return nav;
        }
    },
    
    webview: {
        render: function(data = {}) {
            const webview = document.createElement('div');
            webview.id = data.id || 'webview_' + Date.now();
            webview.classList.add('canvas-component', 'canvas-webview-component');
            webview.dataset.componentType = 'webview';
            
            // Apply properties
            applyComponentProperties(webview, data.properties);
            
            // Add component handle
            const handle = document.createElement('div');
            handle.classList.add('component-handle');
            handle.textContent = 'Web View';
            webview.appendChild(handle);
            
            // Add content container
            const content = document.createElement('div');
            content.classList.add('component-content');
            
            // Show URL or placeholder
            if (data.properties && data.properties.url) {
                content.innerHTML = `
                    <p>Web View Component</p>
                    <p><a href="${data.properties.url}" target="_blank">${data.properties.url}</a></p>
                `;
            } else {
                content.innerHTML = `
                    <p>Web View Component</p>
                    <p class="text-muted">URL will be displayed here</p>
                `;
            }
            
            webview.appendChild(content);
            return webview;
        }
    }
};

// Helper function to apply properties to a component
function applyComponentProperties(element, properties) {
    if (!properties) return;
    
    // Apply style properties
    if (properties.width) element.style.width = properties.width;
    if (properties.height) element.style.height = properties.height;
    if (properties.margin) element.style.margin = properties.margin;
    if (properties.padding) element.style.padding = properties.padding;
    if (properties.backgroundColor) element.style.backgroundColor = properties.backgroundColor;
    if (properties.color) element.style.color = properties.color;
    if (properties.fontSize) element.style.fontSize = properties.fontSize;
    if (properties.fontWeight) element.style.fontWeight = properties.fontWeight;
    if (properties.fontStyle) element.style.fontStyle = properties.fontStyle;
    if (properties.textAlign) element.style.textAlign = properties.textAlign;
    
    // Store other properties as data attributes
    Object.keys(properties).forEach(key => {
        if (!['width', 'height', 'margin', 'padding', 'backgroundColor', 'color', 
              'fontSize', 'fontWeight', 'fontStyle', 'textAlign'].includes(key)) {
            element.dataset[key] = properties[key];
        }
    });
}

// Function to render a component based on its data
function renderComponent(data) {
    if (!data || !data.type) {
        console.error('Invalid component data:', data);
        return null;
    }
    
    const template = componentTemplates[data.type];
    if (!template) {
        console.error('Unknown component type:', data.type);
        return null;
    }
    
    return template.render(data);
}

// Function to render multiple components
function renderComponents(componentsData) {
    const canvas = document.getElementById('appCanvas');
    
    // Clear the canvas
    canvas.innerHTML = '';
    
    // If no components, show placeholder
    if (!componentsData || componentsData.length === 0) {
        canvas.innerHTML = `
            <div class="canvas-placeholder">
                <p>Drag and drop components here to start building your app</p>
            </div>
        `;
        return;
    }
    
    // Render each component
    componentsData.forEach(data => {
        const component = renderComponent(data);
        if (component) {
            canvas.appendChild(component);
        }
    });
    
    // Initialize component event handlers
    initializeComponentEvents();
}

// Initialize event handlers for all components on the canvas
function initializeComponentEvents() {
    // Make all components selectable
    document.querySelectorAll('.canvas-component').forEach(component => {
        component.addEventListener('click', function(e) {
            e.stopPropagation();
            selectComponent(component);
        });
        
        // Make components draggable
        component.setAttribute('draggable', 'true');
        component.addEventListener('dragstart', function(e) {
            e.dataTransfer.setData('text/plain', component.id);
            e.dataTransfer.effectAllowed = 'move';
        });
    });
}

// Function to clone a component (for drag and drop operations)
function cloneComponent(componentData) {
    // Deep clone the component data
    return JSON.parse(JSON.stringify(componentData));
}

// Export functions for use in other modules
window.ComponentUtils = {
    renderComponent,
    renderComponents,
    cloneComponent,
    applyComponentProperties,
    componentTemplates
};
