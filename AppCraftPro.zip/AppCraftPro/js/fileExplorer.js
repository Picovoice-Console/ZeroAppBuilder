/**
 * File Explorer functionality for ZeroApp Builder
 * Enables file browsing, creating, and management in the project
 */

// Track current file structure
let fileStructure = {
    root: {
        type: 'folder',
        name: 'Project',
        children: {}
    }
};

// Track the currently selected file
let selectedFile = null;

/**
 * Initialize the file explorer
 */
function initializeFileExplorer() {
    setupFileButtons();
    loadFileStructure();
    setupSearchFilter();
}

/**
 * Setup event listeners for file explorer buttons
 */
function setupFileButtons() {
    // New file button
    document.getElementById('newFileBtn').addEventListener('click', function() {
        showFileDialog('Create New File', '', createNewFile);
    });
    
    // New folder button
    document.getElementById('newFolderBtn').addEventListener('click', function() {
        showFileDialog('Create New Folder', '', createNewFolder);
    });
    
    // Refresh button
    document.getElementById('refreshFilesBtn').addEventListener('click', function() {
        // Refresh animation
        const icon = this.querySelector('i');
        icon.classList.add('rotating');
        
        // Reload file structure
        setTimeout(() => {
            loadFileStructure();
            icon.classList.remove('rotating');
        }, 500);
    });
}

/**
 * Load/refresh the file structure and render the file tree
 */
function loadFileStructure() {
    // In a real implementation, this would load from server or local storage
    // For demo, we'll use a predefined structure if none exists
    if (Object.keys(fileStructure.root.children).length === 0) {
        // Create some default project files
        fileStructure.root.children = {
            'src': {
                type: 'folder',
                name: 'src',
                children: {
                    'screens': {
                        type: 'folder',
                        name: 'screens',
                        children: {
                            'MainScreen.java': {
                                type: 'file',
                                name: 'MainScreen.java',
                                extension: 'java',
                                content: '// Main screen implementation'
                            },
                            'DetailScreen.java': {
                                type: 'file',
                                name: 'DetailScreen.java',
                                extension: 'java',
                                content: '// Detail screen implementation'
                            }
                        }
                    },
                    'resources': {
                        type: 'folder',
                        name: 'resources',
                        children: {
                            'strings.xml': {
                                type: 'file',
                                name: 'strings.xml',
                                extension: 'xml',
                                content: '<resources>\n  <string name="app_name">My App</string>\n</resources>'
                            },
                            'colors.xml': {
                                type: 'file',
                                name: 'colors.xml',
                                extension: 'xml',
                                content: '<resources>\n  <color name="primary">#3498db</color>\n</resources>'
                            }
                        }
                    },
                    'MainActivity.java': {
                        type: 'file',
                        name: 'MainActivity.java',
                        extension: 'java',
                        content: '// Main activity class'
                    }
                }
            },
            'assets': {
                type: 'folder',
                name: 'assets',
                children: {
                    'images': {
                        type: 'folder',
                        name: 'images',
                        children: {}
                    },
                    'fonts': {
                        type: 'folder',
                        name: 'fonts',
                        children: {}
                    }
                }
            },
            'AndroidManifest.xml': {
                type: 'file',
                name: 'AndroidManifest.xml',
                extension: 'xml',
                content: '<?xml version="1.0" encoding="utf-8"?>\n<manifest>\n  <!-- App manifest -->\n</manifest>'
            },
            'build.gradle': {
                type: 'file',
                name: 'build.gradle',
                extension: 'gradle',
                content: '// Build configuration'
            }
        };
    }
    
    // Render the file tree
    renderFileTree();
}

/**
 * Render the file tree in the UI
 */
function renderFileTree() {
    const container = document.getElementById('fileTreeContainer');
    container.innerHTML = '';
    
    // Recursively render the file structure
    const rootFolder = renderFolder(fileStructure.root, 'root', 0);
    container.appendChild(rootFolder);
    
    // Expand the root folder by default
    rootFolder.querySelector('.file-children').style.display = 'block';
    rootFolder.querySelector('.file-item .file-icon i').setAttribute('data-feather', 'folder-minus');
    
    // Initialize feather icons
    feather.replace();
    
    // Add event listeners to file items
    addFileItemEventListeners();
}

/**
 * Recursively render a folder and its contents
 */
function renderFolder(folder, path, depth) {
    const folderDiv = document.createElement('div');
    folderDiv.className = 'folder-item';
    folderDiv.dataset.path = path;
    
    // Create folder header
    const folderItem = document.createElement('div');
    folderItem.className = 'file-item';
    folderItem.innerHTML = `
        <div class="file-icon">
            <i data-feather="folder" class="folder-icon"></i>
        </div>
        <div class="file-item-name">${folder.name}</div>
    `;
    folderDiv.appendChild(folderItem);
    
    // Create container for children
    const childrenContainer = document.createElement('div');
    childrenContainer.className = 'file-children';
    childrenContainer.style.display = 'none'; // Collapsed by default
    
    // Sort items: folders first, then files
    const sortedChildren = Object.entries(folder.children).sort((a, b) => {
        if (a[1].type === 'folder' && b[1].type === 'file') return -1;
        if (a[1].type === 'file' && b[1].type === 'folder') return 1;
        return a[0].localeCompare(b[0]);
    });
    
    // Add children
    sortedChildren.forEach(([name, item]) => {
        const childPath = path === 'root' ? name : `${path}/${name}`;
        
        if (item.type === 'folder') {
            // Recursively render folders
            childrenContainer.appendChild(renderFolder(item, childPath, depth + 1));
        } else {
            // Render files
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.dataset.path = childPath;
            
            // Get appropriate icon for file type
            let fileIcon = 'file-text';
            if (item.extension === 'java') fileIcon = 'code';
            else if (item.extension === 'xml') fileIcon = 'file-text';
            else if (item.extension === 'gradle') fileIcon = 'settings';
            else if (['png', 'jpg', 'jpeg', 'gif'].includes(item.extension)) fileIcon = 'image';
            
            fileItem.innerHTML = `
                <div class="file-icon">
                    <i data-feather="${fileIcon}"></i>
                </div>
                <div class="file-item-name">${item.name}</div>
            `;
            
            childrenContainer.appendChild(fileItem);
        }
    });
    
    folderDiv.appendChild(childrenContainer);
    return folderDiv;
}

/**
 * Add event listeners to file items
 */
function addFileItemEventListeners() {
    // Folder expand/collapse
    document.querySelectorAll('.folder-item > .file-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Toggle the folder's children visibility
            const children = this.parentElement.querySelector('.file-children');
            const icon = this.querySelector('.file-icon i');
            
            if (children.style.display === 'none') {
                children.style.display = 'block';
                icon.setAttribute('data-feather', 'folder-minus');
            } else {
                children.style.display = 'none';
                icon.setAttribute('data-feather', 'folder');
            }
            
            // Re-initialize feather icons
            feather.replace();
        });
    });
    
    // File selection
    document.querySelectorAll('.file-children .file-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Clear previous selection
            document.querySelectorAll('.file-item.selected').forEach(el => {
                el.classList.remove('selected');
            });
            
            // Select this file
            this.classList.add('selected');
            
            // Store selected file path
            selectedFile = this.dataset.path;
            
            // Show notification
            showNotification(`Selected: ${this.querySelector('.file-item-name').textContent}`, 'info');
            
            // In a real implementation, we would open the file in an editor
            console.log('Selected file:', selectedFile);
        });
    });
    
    // Context menu for files and folders
    document.querySelectorAll('.file-item').forEach(item => {
        item.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            // Show a context menu for file operations
            // This would be implemented in a more sophisticated version
            showNotification('Right-click menu functionality coming soon', 'info');
        });
    });
}

/**
 * Setup the file search filter functionality
 */
function setupSearchFilter() {
    const searchInput = document.getElementById('fileSearch');
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.trim().toLowerCase();
        
        // If search is empty, just show the normal file tree
        if (searchTerm === '') {
            document.querySelectorAll('.folder-item, .file-item').forEach(item => {
                item.style.display = '';
            });
            return;
        }
        
        // Hide all folders initially
        document.querySelectorAll('.folder-item').forEach(folder => {
            folder.style.display = 'none';
        });
        
        // Show file items that match search and their parent folders
        document.querySelectorAll('.file-children .file-item').forEach(file => {
            const fileName = file.querySelector('.file-item-name').textContent.toLowerCase();
            
            if (fileName.includes(searchTerm)) {
                // Show this file
                file.style.display = '';
                
                // Show all parent folders
                let parent = file.parentElement;
                while (parent && !parent.classList.contains('file-tree-container')) {
                    if (parent.classList.contains('file-children')) {
                        parent.style.display = 'block';
                    } else if (parent.classList.contains('folder-item')) {
                        parent.style.display = '';
                    }
                    parent = parent.parentElement;
                }
            } else {
                file.style.display = 'none';
            }
        });
    });
}

/**
 * Show a dialog for file/folder creation
 */
function showFileDialog(title, defaultName, callback) {
    // Create modal if it doesn't exist
    let fileModal = document.getElementById('fileModal');
    
    if (!fileModal) {
        fileModal = document.createElement('div');
        fileModal.id = 'fileModal';
        fileModal.className = 'modal fade';
        fileModal.setAttribute('tabindex', '-1');
        fileModal.setAttribute('aria-hidden', 'true');
        
        fileModal.innerHTML = `
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="fileModalTitle">File Operation</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="fileName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="fileName">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="fileDialogConfirm">Confirm</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(fileModal);
    }
    
    // Set modal properties
    document.getElementById('fileModalTitle').textContent = title;
    document.getElementById('fileName').value = defaultName;
    
    // Show the modal
    const modal = new bootstrap.Modal(fileModal);
    modal.show();
    
    // Set focus on the input
    document.getElementById('fileName').focus();
    
    // Handle confirmation
    document.getElementById('fileDialogConfirm').onclick = function() {
        const name = document.getElementById('fileName').value.trim();
        if (name) {
            callback(name);
            modal.hide();
        } else {
            // Show error if name is empty
            showNotification('Name cannot be empty', 'error');
        }
    };
}

/**
 * Create a new file in the current folder
 */
function createNewFile(name) {
    // Determine file type from extension
    const extension = name.split('.').pop().toLowerCase();
    let content = '';
    
    // Set default content based on file type
    if (extension === 'java') {
        content = `// ${name}\n\npublic class ${name.split('.')[0]} {\n    \n}`;
    } else if (extension === 'xml') {
        content = `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    \n</resources>`;
    }
    
    // Add to file structure (in root for demo purposes)
    fileStructure.root.children[name] = {
        type: 'file',
        name: name,
        extension: extension,
        content: content
    };
    
    // Refresh the file tree
    renderFileTree();
    
    // Show success notification
    showNotification(`File "${name}" created successfully`, 'success');
}

/**
 * Create a new folder
 */
function createNewFolder(name) {
    // Add to file structure (in root for demo purposes)
    fileStructure.root.children[name] = {
        type: 'folder',
        name: name,
        children: {}
    };
    
    // Refresh the file tree
    renderFileTree();
    
    // Show success notification
    showNotification(`Folder "${name}" created successfully`, 'success');
}

/**
 * Export the file structure (e.g. for saving)
 */
function exportFileStructure() {
    return JSON.stringify(fileStructure);
}

/**
 * Import a file structure
 */
function importFileStructure(jsonStructure) {
    try {
        fileStructure = JSON.parse(jsonStructure);
        renderFileTree();
        return true;
    } catch (e) {
        console.error('Error importing file structure:', e);
        return false;
    }
}

/**
 * Get the content of a file by path
 */
function getFileContent(path) {
    const parts = path.split('/');
    let current = fileStructure.root;
    
    // Skip the first part if it's 'root'
    if (parts[0] === 'root') parts.shift();
    
    // Navigate to the file
    for (let i = 0; i < parts.length; i++) {
        if (i === parts.length - 1) {
            // We've reached the file
            if (current.children[parts[i]] && current.children[parts[i]].type === 'file') {
                return current.children[parts[i]].content;
            }
        } else {
            // Navigate to the next folder
            if (current.children[parts[i]] && current.children[parts[i]].type === 'folder') {
                current = current.children[parts[i]];
            } else {
                return null; // Path not found
            }
        }
    }
    
    return null;
}

/**
 * Update the content of a file
 */
function updateFileContent(path, content) {
    const parts = path.split('/');
    let current = fileStructure.root;
    
    // Skip the first part if it's 'root'
    if (parts[0] === 'root') parts.shift();
    
    // Navigate to the file
    for (let i = 0; i < parts.length; i++) {
        if (i === parts.length - 1) {
            // We've reached the file
            if (current.children[parts[i]] && current.children[parts[i]].type === 'file') {
                current.children[parts[i]].content = content;
                return true;
            }
        } else {
            // Navigate to the next folder
            if (current.children[parts[i]] && current.children[parts[i]].type === 'folder') {
                current = current.children[parts[i]];
            } else {
                return false; // Path not found
            }
        }
    }
    
    return false;
}

// CSS animation for refresh button rotation
const rotateStyle = document.createElement('style');
rotateStyle.textContent = `
    .rotating {
        animation: rotate 1s linear infinite;
    }
    
    @keyframes rotate {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(rotateStyle);

// Export the functions for use in other modules
window.fileExplorer = {
    initialize: initializeFileExplorer,
    getFileContent: getFileContent,
    updateFileContent: updateFileContent,
    exportStructure: exportFileStructure,
    importStructure: importFileStructure
};