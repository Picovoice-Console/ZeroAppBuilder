// Project Manager - Handles saving, loading, and managing projects

// Save a project to localStorage
function saveProject(project) {
    if (!project || !project.id) {
        console.error('Cannot save project: Invalid project data');
        return false;
    }
    
    try {
        // Store the project in localStorage
        localStorage.setItem('project_' + project.id, JSON.stringify(project));
        
        // Update the list of projects
        let projectsList = getProjectsList();
        
        // Check if project already exists in the list
        const existingIndex = projectsList.findIndex(p => p.id === project.id);
        
        if (existingIndex >= 0) {
            // Update existing project in list
            projectsList[existingIndex] = {
                id: project.id,
                name: project.name,
                package: project.package,
                lastModified: Date.now()
            };
        } else {
            // Add new project to list
            projectsList.push({
                id: project.id,
                name: project.name,
                package: project.package,
                lastModified: Date.now()
            });
        }
        
        // Save the updated list
        localStorage.setItem('projectsList', JSON.stringify(projectsList));
        
        // Set this as the last used project
        localStorage.setItem('lastProjectId', project.id);
        
        return true;
    } catch (error) {
        console.error('Failed to save project:', error);
        return false;
    }
}

// Load a project from localStorage
function loadProject(projectId) {
    try {
        const projectData = localStorage.getItem('project_' + projectId);
        
        if (!projectData) {
            showNotification('Project not found', 'error');
            return false;
        }
        
        // Parse the project data
        currentProject = JSON.parse(projectData);
        
        // Set current screen to main screen
        currentScreen = 'mainScreen';
        
        // Update UI
        updateProjectUI();
        
        // Render components for the main screen
        if (currentProject.screens && currentProject.screens.mainScreen) {
            renderComponents(currentProject.screens.mainScreen.components || []);
        } else {
            resetCanvas();
        }
        
        // Update icon preview if there's an icon
        if (currentProject.icon) {
            const iconPreview = document.querySelector('.app-icon-preview');
            iconPreview.innerHTML = `<img src="${currentProject.icon}" style="width: 48px; height: 48px; border-radius: 8px;">`;
        }
        
        // Set this as the last used project
        localStorage.setItem('lastProjectId', projectId);
        
        showNotification(`Project "${currentProject.name}" loaded successfully`, 'success');
        return true;
    } catch (error) {
        console.error('Failed to load project:', error);
        showNotification('Failed to load project: ' + error.message, 'error');
        return false;
    }
}

// Get list of all saved projects
function getProjectsList() {
    try {
        const projectsListData = localStorage.getItem('projectsList');
        return projectsListData ? JSON.parse(projectsListData) : [];
    } catch (error) {
        console.error('Failed to retrieve projects list:', error);
        return [];
    }
}

// Populate the load project modal with saved projects
function loadProjects() {
    const projectsList = getProjectsList();
    const projectListElement = document.getElementById('projectList');
    const noProjectsMessage = document.getElementById('noProjectsMessage');
    
    // Clear the current list
    projectListElement.innerHTML = '';
    
    if (projectsList.length === 0) {
        // Show no projects message
        noProjectsMessage.classList.remove('d-none');
    } else {
        // Hide no projects message
        noProjectsMessage.classList.add('d-none');
        
        // Add each project to the list
        projectsList.forEach(project => {
            const lastModified = new Date(project.lastModified).toLocaleString();
            
            const projectItem = document.createElement('a');
            projectItem.href = '#';
            projectItem.classList.add('list-group-item', 'list-group-item-action');
            projectItem.innerHTML = `
                <div class="d-flex w-100 justify-content-between">
                    <h5 class="mb-1">${project.name}</h5>
                    <small>${lastModified}</small>
                </div>
                <p class="mb-1">${project.package}</p>
                <div class="d-flex justify-content-end mt-2">
                    <button class="btn btn-sm btn-outline-danger delete-project-btn" data-project-id="${project.id}">
                        <i data-feather="trash-2"></i>
                    </button>
                </div>
            `;
            
            // Add event listener to load the project
            projectItem.addEventListener('click', function(e) {
                // Don't trigger if delete button was clicked
                if (e.target.closest('.delete-project-btn')) return;
                
                loadProject(project.id);
                bootstrap.Modal.getInstance(document.getElementById('loadProjectModal')).hide();
            });
            
            projectListElement.appendChild(projectItem);
        });
        
        // Initialize delete buttons
        document.querySelectorAll('.delete-project-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const projectId = this.getAttribute('data-project-id');
                deleteProject(projectId);
            });
        });
        
        // Initialize Feather icons
        if (window.feather) {
            feather.replace();
        }
    }
}

// Delete a project
function deleteProject(projectId) {
    if (confirm('Are you sure you want to delete this project? This cannot be undone.')) {
        try {
            // Remove from localStorage
            localStorage.removeItem('project_' + projectId);
            
            // Update the projects list
            let projectsList = getProjectsList();
            projectsList = projectsList.filter(p => p.id !== projectId);
            localStorage.setItem('projectsList', JSON.stringify(projectsList));
            
            // Reload the projects list in the modal
            loadProjects();
            
            // If the current project was deleted, reset the app
            if (currentProject && currentProject.id === projectId) {
                currentProject = null;
                resetCanvas();
                updateProjectUI();
                localStorage.removeItem('lastProjectId');
            }
            
            showNotification('Project deleted successfully', 'success');
        } catch (error) {
            console.error('Failed to delete project:', error);
            showNotification('Failed to delete project: ' + error.message, 'error');
        }
    }
}

// Export the current project
function exportProject() {
    if (!currentProject) {
        showNotification('No project to export', 'error');
        return;
    }
    
    try {
        // Prepare export data
        const exportData = JSON.stringify(currentProject);
        
        // Create a blob with the data
        const blob = new Blob([exportData], { type: 'application/json' });
        
        // Create a download link
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${currentProject.name.replace(/[^a-zA-Z0-9]/g, '_')}.zeroapp`;
        
        // Click the link to trigger download
        document.body.appendChild(a);
        a.click();
        
        // Cleanup
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
        
        showNotification('Project exported successfully', 'success');
    } catch (error) {
        console.error('Failed to export project:', error);
        showNotification('Failed to export project: ' + error.message, 'error');
    }
}

// Import a project from a file
function importProject(file) {
    if (!file) {
        showNotification('No file selected', 'error');
        return;
    }
    
    // Check file extension
    if (!file.name.endsWith('.zeroapp')) {
        showNotification('Invalid file format. Please select a .zeroapp file.', 'error');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            // Parse the file content
            const projectData = JSON.parse(e.target.result);
            
            // Basic validation
            if (!projectData.id || !projectData.name || !projectData.package) {
                throw new Error('Invalid project format');
            }
            
            // Generate new ID to avoid conflicts
            projectData.id = 'project_' + Date.now();
            
            // Save the imported project
            currentProject = projectData;
            saveProject(currentProject);
            
            // Update UI
            updateProjectUI();
            
            // Render components
            currentScreen = 'mainScreen';
            if (currentProject.screens && currentProject.screens.mainScreen) {
                renderComponents(currentProject.screens.mainScreen.components || []);
            } else {
                resetCanvas();
            }
            
            // Hide the modal
            bootstrap.Modal.getInstance(document.getElementById('loadProjectModal')).hide();
            
            showNotification(`Project "${currentProject.name}" imported successfully`, 'success');
        } catch (error) {
            console.error('Failed to import project:', error);
            showNotification('Failed to import project: ' + error.message, 'error');
        }
    };
    
    reader.onerror = function() {
        showNotification('Error reading file', 'error');
    };
    
    reader.readAsText(file);
}

// Create a backup of all projects
function backupAllProjects() {
    try {
        // Get all project IDs
        const projectsList = getProjectsList();
        
        if (projectsList.length === 0) {
            showNotification('No projects to backup', 'info');
            return;
        }
        
        // Collect all project data
        const projectsData = {};
        projectsList.forEach(project => {
            const projectData = localStorage.getItem('project_' + project.id);
            if (projectData) {
                projectsData['project_' + project.id] = JSON.parse(projectData);
            }
        });
        
        // Add projects list
        projectsData.projectsList = projectsList;
        
        // Create a backup file
        const backupData = JSON.stringify(projectsData);
        const blob = new Blob([backupData], { type: 'application/json' });
        
        // Trigger download
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `ZeroAppBuilder_Backup_${new Date().toISOString().split('T')[0]}.json`;
        
        document.body.appendChild(a);
        a.click();
        
        // Cleanup
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
        
        showNotification('All projects backed up successfully', 'success');
    } catch (error) {
        console.error('Failed to backup projects:', error);
        showNotification('Failed to backup projects: ' + error.message, 'error');
    }
}

// Restore projects from backup
function restoreProjects(backupFile) {
    if (!backupFile) {
        showNotification('No backup file selected', 'error');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            // Parse the backup data
            const backupData = JSON.parse(e.target.result);
            
            // Validate backup data
            if (!backupData.projectsList || !Array.isArray(backupData.projectsList)) {
                throw new Error('Invalid backup format');
            }
            
            // Confirm restore
            if (!confirm('This will overwrite any existing projects with the same IDs. Continue?')) {
                return;
            }
            
            // Restore projects list
            localStorage.setItem('projectsList', JSON.stringify(backupData.projectsList));
            
            // Restore individual projects
            let restoredCount = 0;
            backupData.projectsList.forEach(project => {
                const projectData = backupData['project_' + project.id];
                if (projectData) {
                    localStorage.setItem('project_' + project.id, JSON.stringify(projectData));
                    restoredCount++;
                }
            });
            
            showNotification(`Restored ${restoredCount} projects successfully`, 'success');
            
            // Reload projects list
            loadProjects();
        } catch (error) {
            console.error('Failed to restore backup:', error);
            showNotification('Failed to restore backup: ' + error.message, 'error');
        }
    };
    
    reader.onerror = function() {
        showNotification('Error reading backup file', 'error');
    };
    
    reader.readAsText(backupFile);
}

// Add event listener for the export/import functionality (to be called at app initialization)
function initializeProjectManagement() {
    // Add export button to load project modal
    const loadProjectModal = document.getElementById('loadProjectModal');
    if (loadProjectModal) {
        const modalFooter = loadProjectModal.querySelector('.modal-footer');
        if (modalFooter) {
            // Add export all projects button
            const exportAllBtn = document.createElement('button');
            exportAllBtn.type = 'button';
            exportAllBtn.classList.add('btn', 'btn-outline-primary', 'me-auto');
            exportAllBtn.textContent = 'Backup All Projects';
            exportAllBtn.addEventListener('click', backupAllProjects);
            
            // Add restore button
            const restoreBtn = document.createElement('button');
            restoreBtn.type = 'button';
            restoreBtn.classList.add('btn', 'btn-outline-secondary');
            restoreBtn.textContent = 'Restore Backup';
            restoreBtn.addEventListener('click', function() {
                // Create a file input
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.json';
                input.onchange = function(e) {
                    if (e.target.files.length > 0) {
                        restoreProjects(e.target.files[0]);
                    }
                };
                input.click();
            });
            
            // Insert before the Cancel button
            modalFooter.insertBefore(exportAllBtn, modalFooter.firstChild);
            modalFooter.insertBefore(restoreBtn, modalFooter.querySelector('.btn-secondary'));
        }
    }
    
    // Export current project button
    document.getElementById('exportProjectBtn')?.addEventListener('click', exportProject);
}

// Initialize the project management when the app is loaded
window.addEventListener('DOMContentLoaded', initializeProjectManagement);
