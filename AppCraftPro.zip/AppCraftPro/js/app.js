document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    feather.replace();
    
    // Initialize modals
    const newProjectModal = new bootstrap.Modal(document.getElementById('newProjectModal'), {});
    const loadProjectModal = new bootstrap.Modal(document.getElementById('loadProjectModal'), {});
    const exportModal = new bootstrap.Modal(document.getElementById('exportModal'), {});
    const processingModal = new bootstrap.Modal(document.getElementById('processingModal'), {});
    const helpModal = new bootstrap.Modal(document.getElementById('helpModal'), {});
    const aiAssistModal = new bootstrap.Modal(document.getElementById('aiAssistModal'), {});
    
    // Initialize theme preference
    initializeTheme();
    
    // Initialize the app
    initializeApp();
    
    // Event listeners for toolbar buttons
    document.getElementById('newProjectBtn').addEventListener('click', function() {
        newProjectModal.show();
    });
    
    document.getElementById('loadProjectBtn').addEventListener('click', function() {
        loadProjects();
        loadProjectModal.show();
    });
    
    document.getElementById('exportBtn').addEventListener('click', function() {
        validateBeforeExport() ? exportModal.show() : alert('Please complete your app setup before exporting.');
    });
    
    document.getElementById('downloadSourceBtn').addEventListener('click', function() {
        // Create a notification
        showNotification('Preparing download of source code...', 'info');
        
        // Trigger the download
        window.location.href = '/download-source';
    });
    
    document.getElementById('aiAssistBtn').addEventListener('click', function() {
        aiAssistModal.show();
        // Reset the AI chat interface when opened
        document.getElementById('aiResponseArea').classList.add('d-none');
        document.querySelector('.ai-response-content').innerHTML = '';
    });
    
    // Theme toggle
    document.getElementById('toggleThemeBtn').addEventListener('click', function() {
        toggleTheme();
    });
    
    // New project creation
    document.getElementById('createProjectBtn').addEventListener('click', function() {
        const appName = document.getElementById('newAppName').value;
        const appPackage = document.getElementById('newAppPackage').value;
        const template = document.getElementById('templateSelect').value;
        
        if (!appName || !appPackage) {
            alert('Please fill in all required fields.');
            return;
        }
        
        if (!validatePackageName(appPackage)) {
            alert('Invalid package name. It should be in the format: com.example.myapp');
            return;
        }
        
        createNewProject(appName, appPackage, template);
        newProjectModal.hide();
    });
    
    // Handle keystore option change
    document.querySelectorAll('input[name="keystoreOption"]').forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.id === 'newKeystore') {
                document.getElementById('newKeystoreOptions').classList.remove('d-none');
                document.getElementById('existingKeystoreOptions').classList.add('d-none');
            } else {
                document.getElementById('newKeystoreOptions').classList.add('d-none');
                document.getElementById('existingKeystoreOptions').classList.remove('d-none');
            }
        });
    });
    
    // APK generation
    document.getElementById('generateApkBtn').addEventListener('click', function() {
        const isNewKeystore = document.getElementById('newKeystore').checked;
        let keystorePath, keystorePassword;
        
        if (isNewKeystore) {
            keystorePassword = document.getElementById('keystorePassword').value;
            if (!keystorePassword) {
                alert('Please enter a keystore password.');
                return;
            }
            generateAPK(true, null, keystorePassword);
        } else {
            const keystoreFile = document.getElementById('uploadKeystore').files[0];
            keystorePassword = document.getElementById('existingKeystorePassword').value;
            
            if (!keystoreFile || !keystorePassword) {
                alert('Please upload a keystore file and enter the password.');
                return;
            }
            
            generateAPK(false, keystoreFile, keystorePassword);
        }
        
        exportModal.hide();
        showProcessingModal('Generating APK', 'This may take a few minutes. Please do not close this window.');
    });
    
    // Device preview controls
    document.getElementById('previewMobile').addEventListener('click', function() {
        document.getElementById('appCanvas').className = 'app-canvas phone-preview';
    });
    
    document.getElementById('previewTablet').addEventListener('click', function() {
        document.getElementById('appCanvas').className = 'app-canvas tablet-preview';
    });

    // Screen selector change
    document.getElementById('screenSelector').addEventListener('change', function() {
        const selectedValue = this.value;
        
        if (selectedValue === 'addScreen') {
            // Reset the dropdown to current selection
            this.value = currentScreen;
            
            // Prompt user for new screen name
            const screenName = prompt('Enter a name for the new screen:', 'Screen' + (getScreenCount() + 1));
            if (screenName && screenName.trim()) {
                addNewScreen(screenName.trim());
                // Update the dropdown
                const option = document.createElement('option');
                option.value = screenName;
                option.textContent = screenName;
                this.insertBefore(option, this.lastElementChild);
                this.value = screenName;
                currentScreen = screenName;
                switchScreen(currentScreen);
            }
        } else {
            // Switch to the selected screen
            currentScreen = selectedValue;
            switchScreen(currentScreen);
        }
    });

    // App settings change handlers
    document.getElementById('appName').addEventListener('change', function() {
        updateAppSettings('name', this.value);
    });
    
    document.getElementById('appPackage').addEventListener('change', function() {
        if (validatePackageName(this.value)) {
            updateAppSettings('package', this.value);
        } else {
            alert('Invalid package name. It should be in the format: com.example.myapp');
            this.value = currentProject.package;
        }
    });
    
    document.getElementById('appVersion').addEventListener('change', function() {
        updateAppSettings('version', this.value);
    });
    
    // Upload icon button
    document.getElementById('uploadIconBtn').addEventListener('click', function() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = function(e) {
            const file = e.target.files[0];
            if (file) {
                handleIconUpload(file);
            }
        };
        input.click();
    });
    
    // Import project button
    document.getElementById('importProjectBtn').addEventListener('click', function() {
        const fileInput = document.getElementById('importProject');
        if (fileInput.files.length > 0) {
            importProject(fileInput.files[0]);
        } else {
            alert('Please select a project file to import.');
        }
    });
});

// Global variables
let currentProject = null;
let currentScreen = 'mainScreen';
let selectedElement = null;

// Theme management functions
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
    updateThemeIcon(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    updateThemeIcon(newTheme);
    
    // Save theme preference
    localStorage.setItem('theme', newTheme);
    
    // If project exists, save theme preference in project settings
    if (currentProject && currentProject.settings) {
        currentProject.settings.theme = newTheme;
        saveProject(currentProject);
    }
    
    // Show notification
    showNotification(`Switched to ${newTheme} mode`, 'info');
}

function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
}

function updateThemeIcon(theme) {
    const themeButton = document.getElementById('toggleThemeBtn');
    const themeIcon = themeButton.querySelector('i');
    
    if (themeIcon) {
        themeIcon.setAttribute('data-feather', theme === 'light' ? 'moon' : 'sun');
        feather.replace();
    }
}

function initializeApp() {
    // Initialize canvas with placeholder
    resetCanvas();
    
    // Initialize components draggable functionality
    initializeDragAndDrop();
    
    // Initialize component selection
    initializeComponentSelection();
    
    // Initialize AI Assistant
    initializeAIAssistant();
    
    // Initialize sidebar tabs
    initializeSidebarTabs();
    
    // Initialize property tabs
    initializePropertyTabs();
    
    // Initialize component group toggle
    initializeComponentGroups();
    
    // Initialize canvas zoom controls
    initializeZoomControls();
    
    // Check local storage for any previous project
    const lastProject = localStorage.getItem('lastProjectId');
    if (lastProject) {
        loadProject(lastProject);
    }
    
    // Update project name in navbar
    updateNavProjectName();
}

// Left sidebar tab switching
function initializeSidebarTabs() {
    const tabButtons = document.querySelectorAll('.left-sidebar-tabs .tab-btn');
    
    tabButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all tabs
            tabButtons.forEach(tb => tb.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Hide all tab content
            document.querySelectorAll('.left-sidebar .tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Show selected tab content
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
            
            // Show a notification for new features
            if (tabId === 'files-tab') {
                showNotification('File explorer gives you access to your project resources', 'info');
            } else if (tabId === 'assets-tab') {
                showNotification('Easily manage your app assets in one place', 'info');
            }
        });
    });
}

// Properties panel tab switching
function initializePropertyTabs() {
    const propTabButtons = document.querySelectorAll('.properties-tabs .prop-tab-btn');
    
    propTabButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all tabs
            propTabButtons.forEach(tb => tb.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Hide all tab content
            document.querySelectorAll('.properties-panel .prop-tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Show selected tab content
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
}

// Component group collapse/expand functionality
function initializeComponentGroups() {
    const groupHeaders = document.querySelectorAll('.component-group-header');
    
    groupHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const group = this.closest('.component-group');
            group.classList.toggle('collapsed');
        });
    });
    
    // Collapse all button functionality
    document.getElementById('collapseAllBtn').addEventListener('click', function() {
        const isAnyExpanded = document.querySelector('.component-group:not(.collapsed)');
        
        if (isAnyExpanded) {
            // If any group is expanded, collapse all
            document.querySelectorAll('.component-group').forEach(group => {
                group.classList.add('collapsed');
            });
            this.querySelector('i').setAttribute('data-feather', 'chevrons-down');
        } else {
            // If all are collapsed, expand all
            document.querySelectorAll('.component-group').forEach(group => {
                group.classList.remove('collapsed');
            });
            this.querySelector('i').setAttribute('data-feather', 'chevrons-up');
        }
        
        // Reinitialize feather icons
        feather.replace();
    });
}

// Canvas zoom controls
function initializeZoomControls() {
    let zoomLevel = 100;
    const zoomStep = 10;
    const zoomLevelDisplay = document.querySelector('.zoom-level');
    const canvas = document.getElementById('appCanvas');
    
    document.getElementById('zoomInBtn').addEventListener('click', function() {
        if (zoomLevel < 200) {
            zoomLevel += zoomStep;
            updateZoom();
        }
    });
    
    document.getElementById('zoomOutBtn').addEventListener('click', function() {
        if (zoomLevel > 50) {
            zoomLevel -= zoomStep;
            updateZoom();
        }
    });
    
    document.getElementById('zoomResetBtn').addEventListener('click', function() {
        zoomLevel = 100;
        updateZoom();
    });
    
    function updateZoom() {
        // Update the zoom level display
        zoomLevelDisplay.textContent = `${zoomLevel}%`;
        
        // Apply scale transform to the canvas content
        const scale = zoomLevel / 100;
        
        // Scale all child elements in the canvas except the canvas itself
        Array.from(canvas.children).forEach(child => {
            if (!child.classList.contains('canvas-placeholder')) {
                child.style.transform = `scale(${scale})`;
                child.style.transformOrigin = 'top left';
            }
        });
    }
}

function resetCanvas() {
    const canvas = document.getElementById('appCanvas');
    canvas.innerHTML = `
        <div class="canvas-placeholder">
            <div class="placeholder-content">
                <i data-feather="layout" class="mb-3"></i>
                <p>Drag and drop components here to start building your app</p>
                <button class="btn btn-primary btn-sm mt-2" id="startTemplateBtn">
                    <i data-feather="package" class="me-1"></i> Start With Template
                </button>
            </div>
        </div>
    `;
    
    // Re-initialize feather icons
    feather.replace();
    
    // Add event listener to template button
    const templateBtn = document.getElementById('startTemplateBtn');
    if (templateBtn) {
        templateBtn.addEventListener('click', function() {
            const newProjectModal = new bootstrap.Modal(document.getElementById('newProjectModal'));
            newProjectModal.show();
        });
    }
}

function createNewProject(name, packageName, templateType) {
    // Create new project object
    currentProject = {
        id: 'project_' + Date.now(),
        name: name,
        package: packageName,
        version: '1.0.0',
        screens: {
            mainScreen: {
                name: 'Main Screen',
                components: []
            }
        },
        settings: {
            orientation: 'portrait',
            theme: 'light'
        }
    };
    
    // Save to localStorage
    saveProject(currentProject);
    
    // Set current screen
    currentScreen = 'mainScreen';
    
    // Update UI with project info
    updateProjectUI();
    
    // Apply template if not blank
    if (templateType !== 'blank') {
        applyTemplate(templateType);
    } else {
        resetCanvas();
    }
}

function applyTemplate(templateType) {
    // Clear canvas
    resetCanvas();
    
    if (templateType === 'basic') {
        // Apply basic navigation template
        const basicTemplate = [
            {
                type: 'container',
                id: 'container_' + Date.now(),
                styles: { padding: '10px' },
                children: [
                    {
                        type: 'text',
                        id: 'header_' + Date.now(),
                        content: currentProject.name,
                        styles: { fontSize: '24px', fontWeight: 'bold', marginBottom: '20px' }
                    },
                    {
                        type: 'text',
                        id: 'welcome_' + Date.now(),
                        content: 'Welcome to my app!',
                        styles: { marginBottom: '20px' }
                    },
                    {
                        type: 'button',
                        id: 'button_' + Date.now(),
                        content: 'Click Me',
                        styles: { backgroundColor: '#4285f4', color: 'white' },
                        actions: { onClick: 'alert("Button clicked!")' }
                    }
                ]
            }
        ];
        
        currentProject.screens.mainScreen.components = basicTemplate;
        renderComponents(basicTemplate);
        
    } else if (templateType === 'tabs') {
        // Create tab screens
        currentProject.screens.homeScreen = {
            name: 'Home',
            components: []
        };
        
        currentProject.screens.infoScreen = {
            name: 'Info',
            components: []
        };
        
        currentProject.screens.settingsScreen = {
            name: 'Settings',
            components: []
        };
        
        // Create tab navigation
        const tabsTemplate = [
            {
                type: 'navigation',
                id: 'tabs_' + Date.now(),
                style: 'tabs',
                items: [
                    { label: 'Home', screen: 'homeScreen' },
                    { label: 'Info', screen: 'infoScreen' },
                    { label: 'Settings', screen: 'settingsScreen' }
                ]
            },
            {
                type: 'container',
                id: 'content_' + Date.now(),
                styles: { padding: '10px', minHeight: '300px' },
                children: [
                    {
                        type: 'text',
                        id: 'mainInfo_' + Date.now(),
                        content: 'Welcome to the tabbed app template. Navigate using the tabs above.',
                        styles: { margin: '20px 0' }
                    }
                ]
            }
        ];
        
        currentProject.screens.mainScreen.components = tabsTemplate;
        renderComponents(tabsTemplate);
        
        // Update screen selector
        updateScreenSelector();
    }
    
    // Save the updated project with template
    saveProject(currentProject);
}

function updateProjectUI() {
    // Update app name and package in the UI
    document.getElementById('appName').value = currentProject.name || '';
    document.getElementById('appPackage').value = currentProject.package || '';
    document.getElementById('appVersion').value = currentProject.version || '1.0.0';
    
    // Update screen selector
    updateScreenSelector();
    
    // Update navbar project name
    updateNavProjectName();
}

function updateNavProjectName() {
    const navProjectName = document.getElementById('navProjectName');
    if (navProjectName) {
        if (currentProject && currentProject.name) {
            navProjectName.textContent = currentProject.name;
        } else {
            navProjectName.textContent = 'App Builder';
        }
    }
}

function updateScreenSelector() {
    const screenSelector = document.getElementById('screenSelector');
    screenSelector.innerHTML = '';
    
    // Add all screens from the project
    Object.keys(currentProject.screens).forEach(screenId => {
        const option = document.createElement('option');
        option.value = screenId;
        option.textContent = currentProject.screens[screenId].name;
        screenSelector.appendChild(option);
    });
    
    // Add the "Add Screen" option
    const addOption = document.createElement('option');
    addOption.value = 'addScreen';
    addOption.textContent = '+ Add Screen';
    screenSelector.appendChild(addOption);
    
    // Set current selected screen
    screenSelector.value = currentScreen;
}

function switchScreen(screenId) {
    if (currentProject && currentProject.screens[screenId]) {
        // Save current screen before switching
        saveCurrentScreenState();
        
        // Update current screen
        currentScreen = screenId;
        
        // Render the components for this screen
        renderComponents(currentProject.screens[screenId].components || []);
        
        // Update screen selector
        document.getElementById('screenSelector').value = screenId;
    }
}

function saveCurrentScreenState() {
    if (currentProject && currentScreen) {
        // Capture the current state of the canvas
        currentProject.screens[currentScreen].components = captureCanvasState();
        
        // Save the project
        saveProject(currentProject);
    }
}

function captureCanvasState() {
    // This function should extract the component hierarchy from the canvas
    // For simplicity, we'll return an empty array in this example
    // In a real implementation, you would traverse the DOM and convert it to your component model
    return [];
}

function getScreenCount() {
    return Object.keys(currentProject.screens).length;
}

function addNewScreen(screenName) {
    // Generate a screen ID (sanitized name for use as ID)
    const screenId = screenName.toLowerCase().replace(/[^a-z0-9]/g, '') + '_' + Date.now();
    
    // Add the screen to the project
    currentProject.screens[screenId] = {
        name: screenName,
        components: []
    };
    
    // Save the project
    saveProject(currentProject);
    
    return screenId;
}

function updateAppSettings(setting, value) {
    if (currentProject) {
        switch (setting) {
            case 'name':
                currentProject.name = value;
                break;
            case 'package':
                currentProject.package = value;
                break;
            case 'version':
                currentProject.version = value;
                break;
        }
        
        // Save the updated project
        saveProject(currentProject);
    }
}

function validatePackageName(packageName) {
    // Simple validation for package name format
    const packageRegex = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+[0-9a-z_]$/i;
    return packageRegex.test(packageName);
}

function validateBeforeExport() {
    if (!currentProject) return false;
    
    // Check required fields
    if (!currentProject.name || !currentProject.package || !currentProject.version) {
        return false;
    }
    
    // Check if there are any components on the main screen
    if (!currentProject.screens.mainScreen.components || 
        currentProject.screens.mainScreen.components.length === 0) {
        return false;
    }
    
    return true;
}

function showProcessingModal(title, message) {
    document.getElementById('processingMessage').textContent = title;
    document.getElementById('processingDetails').textContent = message;
    const processingModal = new bootstrap.Modal(document.getElementById('processingModal'));
    processingModal.show();
}

function hideProcessingModal() {
    const processingModalEl = document.getElementById('processingModal');
    const processingModal = bootstrap.Modal.getInstance(processingModalEl);
    if (processingModal) {
        processingModal.hide();
    }
}

function handleIconUpload(file) {
    // Create a file reader to read the icon file
    const reader = new FileReader();
    reader.onload = function(event) {
        // Store the icon data in the project
        if (currentProject) {
            currentProject.icon = event.target.result;
            saveProject(currentProject);
            
            // Update the icon preview
            const iconPreview = document.querySelector('.app-icon-preview');
            iconPreview.innerHTML = `<img src="${event.target.result}" style="width: 48px; height: 48px; border-radius: 8px;">`;
        }
    };
    reader.readAsDataURL(file);
}

// Initialization functions
function initializeDragAndDrop() {
    // Implement drag-and-drop functionality for components
    // This is just a placeholder; actual implementation would be more complex
    console.log('Drag and drop initialized');
}

function initializeComponentSelection() {
    // Implement component selection functionality
    // This is just a placeholder; actual implementation would be more complex
    console.log('Component selection initialized');
}

// Helper function to render a notification
function showNotification(message, type = 'info') {
    // Create notification container if it doesn't exist
    let notificationsContainer = document.getElementById('notificationsContainer');
    if (!notificationsContainer) {
        notificationsContainer = document.createElement('div');
        notificationsContainer.id = 'notificationsContainer';
        notificationsContainer.className = 'notifications-container';
        document.body.appendChild(notificationsContainer);
    }
    
    // Generate a unique ID for this notification
    const notificationId = 'notification_' + Date.now();
    
    // Create notification element
    const notification = document.createElement('div');
    notification.id = notificationId;
    notification.className = `notification notification-${type} animate__animated animate__fadeInRight`;
    
    // Get icon based on type
    let icon;
    switch (type) {
        case 'success':
            icon = 'check-circle';
            break;
        case 'warning':
            icon = 'alert-triangle';
            break;
        case 'error':
            icon = 'alert-octagon';
            break;
        default:
            icon = 'info';
    }
    
    // Set notification content
    notification.innerHTML = `
        <div class="notification-icon">
            <i data-feather="${icon}"></i>
        </div>
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close" aria-label="Close">
            <i data-feather="x"></i>
        </button>
    `;
    
    // Add to container
    notificationsContainer.appendChild(notification);
    
    // Initialize Feather icons
    feather.replace();
    
    // Add click event for close button
    notification.querySelector('.notification-close').addEventListener('click', function() {
        closeNotification(notificationId);
    });
    
    // Auto-close after 5 seconds
    setTimeout(() => {
        closeNotification(notificationId);
    }, 5000);
    
    // Log to console as well
    console.log(`${type.toUpperCase()}: ${message}`);
}

function closeNotification(id) {
    const notification = document.getElementById(id);
    if (notification) {
        notification.classList.remove('animate__fadeInRight');
        notification.classList.add('animate__fadeOutRight');
        
        // Remove element after animation completes
        setTimeout(() => {
            notification.remove();
        }, 500);
    }
}

// AI Assistant functionality
function initializeAIAssistant() {
    // Initialize AI suggestion cards
    document.querySelectorAll('.ai-suggestion-card').forEach(card => {
        card.addEventListener('click', function() {
            const suggestion = this.getAttribute('data-suggestion');
            handleAISuggestion(suggestion);
        });
    });
    
    // AI chat submit button
    document.getElementById('aiSubmitBtn').addEventListener('click', function() {
        submitAIQuery();
    });
    
    // AI chat input enter key press
    document.getElementById('aiQueryInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            submitAIQuery();
        }
    });
}

function submitAIQuery() {
    const queryInput = document.getElementById('aiQueryInput');
    const query = queryInput.value.trim();
    
    if (!query) return;
    
    // Clear input field
    queryInput.value = '';
    
    // Show response area and loading indicator
    document.getElementById('aiResponseArea').classList.remove('d-none');
    document.querySelector('.ai-response-loading').classList.remove('d-none');
    
    // Simulate processing time
    setTimeout(() => {
        // Hide loading indicator
        document.querySelector('.ai-response-loading').classList.add('d-none');
        
        // Generate AI response
        const response = generateAIResponse(query);
        
        // Display response
        const responseContent = document.querySelector('.ai-response-content');
        responseContent.innerHTML = `
            <div class="ai-message-box mb-3">
                <div class="ai-avatar">
                    <i data-feather="user"></i>
                </div>
                <div class="ai-message">
                    <p class="m-0"><strong>You:</strong> ${query}</p>
                </div>
            </div>
            <div class="ai-message-box">
                <div class="ai-avatar">
                    <i data-feather="cpu"></i>
                </div>
                <div class="ai-message">
                    <div class="mb-2">${response}</div>
                </div>
            </div>
        `;
        
        // Re-initialize feather icons
        feather.replace();
    }, 1000);
}

function handleAISuggestion(suggestion) {
    let response = '';
    
    switch (suggestion) {
        case 'layout':
            response = `
                <h6>Layout Design Tips</h6>
                <ol>
                    <li><strong>Use consistent spacing:</strong> Keep padding and margins consistent throughout your app for a polished look.</li>
                    <li><strong>Group related elements:</strong> Use containers to group related UI elements together.</li>
                    <li><strong>Consider device orientation:</strong> Design your layout to work well in both portrait and landscape modes.</li>
                    <li><strong>Follow material design guidelines:</strong> Use standard component sizes and spacing for a professional look.</li>
                </ol>
                <p>Need more specific help with your layout? Just ask!</p>
            `;
            break;
        case 'navigation':
            response = `
                <h6>App Navigation Best Practices</h6>
                <ol>
                    <li><strong>Keep it simple:</strong> Limit navigation levels to 2-3 deep at most.</li>
                    <li><strong>Use standard patterns:</strong> Tabs, drawers, and bottom navigation are familiar to users.</li>
                    <li><strong>Provide clear feedback:</strong> Make sure users know where they are in your app.</li>
                    <li><strong>Include back navigation:</strong> Always provide a way to go back or return to the home screen.</li>
                </ol>
                <p>To add navigation, drag the Navigation component onto your canvas and customize its properties.</p>
            `;
            break;
        case 'components':
            response = `
                <h6>Component Usage Guidelines</h6>
                <ul>
                    <li><strong>Containers:</strong> Use to group related elements and apply consistent padding.</li>
                    <li><strong>Buttons:</strong> Make them large enough to tap easily (at least 48x48dp) and use clear action verbs.</li>
                    <li><strong>Text:</strong> Use consistent fonts and sizes. Ensure good contrast for readability.</li>
                    <li><strong>Lists:</strong> Perfect for presenting repeating data in a clean, scannable format.</li>
                    <li><strong>Inputs:</strong> Always include clear labels and validation feedback.</li>
                </ul>
                <p>You can customize any component by selecting it and using the Properties panel.</p>
            `;
            break;
        case 'publishing':
            response = `
                <h6>Publishing to Google Play Store</h6>
                <ol>
                    <li><strong>Create a Developer Account:</strong> Register at <a href="https://play.google.com/console/" target="_blank">Google Play Console</a> ($25 one-time fee).</li>
                    <li><strong>Export Your APK:</strong> Use the "Export APK" option from ZeroApp Builder.</li>
                    <li><strong>Prepare Store Listing:</strong> You'll need screenshots, icon, descriptions, and privacy policy.</li>
                    <li><strong>Upload Your APK:</strong> In the Play Console, create a new app and upload your APK file.</li>
                    <li><strong>Set Up Pricing & Distribution:</strong> Choose countries, pricing (free/paid), and content rating.</li>
                    <li><strong>Submit for Review:</strong> Google will review your app before publishing (can take 1-3 days).</li>
                </ol>
                <p>ZeroApp Builder handles the complex technical work, but you'll need to complete the store listing yourself.</p>
            `;
            break;
        default:
            response = "I'm not sure how to help with that specific topic. Please try asking a direct question.";
    }
    
    // Display response
    document.getElementById('aiResponseArea').classList.remove('d-none');
    document.querySelector('.ai-response-loading').classList.add('d-none');
    document.querySelector('.ai-response-content').innerHTML = response;
    
    // Re-initialize feather icons
    feather.replace();
}

function generateAIResponse(query) {
    // Convert query to lowercase for easier matching
    const lowerQuery = query.toLowerCase();
    
    // Common responses based on keywords
    if (lowerQuery.includes('template') || lowerQuery.includes('starter')) {
        return `
            <h6>Using Templates</h6>
            <p>ZeroApp Builder offers three starter templates:</p>
            <ul>
                <li><strong>Blank App:</strong> A completely empty app for maximum customization.</li>
                <li><strong>Basic Navigation:</strong> A simple app with a header and basic navigation structure.</li>
                <li><strong>Tabbed App:</strong> An app with tab-based navigation for switching between multiple screens.</li>
            </ul>
            <p>You can select a template when creating a new project. Templates help you get started quickly without having to set up common structures from scratch.</p>
        `;
    } else if (lowerQuery.includes('cost') || lowerQuery.includes('price') || lowerQuery.includes('free')) {
        return `
            <h6>ZeroApp Builder Costs</h6>
            <p>ZeroApp Builder is completely free to use, with no hidden costs for creating and exporting Android apps.</p>
            <p>The only cost you might encounter is the one-time $25 fee to register as a developer on Google Play Store if you want to publish your app there. This fee goes to Google, not to ZeroApp Builder.</p>
            <p>There are no limitations on the apps you create, no watermarks, and no subscription fees!</p>
        `;
    } else if (lowerQuery.includes('export') || lowerQuery.includes('apk') || lowerQuery.includes('build')) {
        return `
            <h6>Exporting Your App</h6>
            <p>To export your app as an APK file:</p>
            <ol>
                <li>Complete your app design using the builder.</li>
                <li>Fill in all required App Settings (name, package name, version).</li>
                <li>Click the "Export APK" button in the top navigation.</li>
                <li>Choose whether to create a new keystore or use an existing one. <strong>Remember your keystore password</strong> - you'll need it for future updates!</li>
                <li>Click "Generate APK" and wait for the process to complete.</li>
                <li>Download your APK file when prompted.</li>
            </ol>
            <p>The APK file can be installed on Android devices or uploaded to the Google Play Store.</p>
        `;
    } else if (lowerQuery.includes('screen') || lowerQuery.includes('page')) {
        return `
            <h6>Working with Screens</h6>
            <p>Screens represent different views in your app. Here's how to manage them:</p>
            <ol>
                <li>To add a new screen, select "+" in the screen dropdown above the canvas.</li>
                <li>To switch between screens, use the same dropdown menu.</li>
                <li>Each screen has its own layout and components that you can customize.</li>
                <li>To create navigation between screens, use the Navigation component and set its properties.</li>
            </ol>
            <p>Tip: Plan your screens before building! Sketch out what information and interactions will be on each screen.</p>
        `;
    } else if (lowerQuery.includes('component') || lowerQuery.includes('element') || lowerQuery.includes('widget')) {
        return `
            <h6>Working with Components</h6>
            <p>Components are the building blocks of your app. Here's how to use them:</p>
            <ol>
                <li>Drag components from the left sidebar onto your canvas.</li>
                <li>Select a component to edit its properties in the right panel.</li>
                <li>Use Container components to group related elements together.</li>
                <li>Components can be nested inside containers for complex layouts.</li>
            </ol>
            <p>Available components include layout elements (Container, Row), UI elements (Button, Text, Image, Input), and functional components (List, Navigation, Web View).</p>
        `;
    } else {
        // Default response for queries that don't match specific patterns
        return `
            <p>I'll do my best to help with your question about "${query}". Here are some general tips for building your app:</p>
            <ul>
                <li>Start with a clear plan of what screens you need and how they connect.</li>
                <li>Use containers to organize your layout and create consistent spacing.</li>
                <li>Test your design frequently to ensure it looks good on different screen sizes.</li>
                <li>Remember to fill in all App Settings before exporting your APK.</li>
            </ul>
            <p>For more specific guidance, try asking about templates, components, screens, or the export process.</p>
        `;
    }
}
