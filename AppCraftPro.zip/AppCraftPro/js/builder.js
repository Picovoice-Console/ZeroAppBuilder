// Builder.js - Handles the drag and drop functionality and canvas interaction

// Initialize drag and drop functionality
function initializeDragAndDrop() {
    // Make component items draggable
    const componentItems = document.querySelectorAll('.component-item');
    componentItems.forEach(item => {
        item.addEventListener('dragstart', handleDragStart);
    });
    
    // Set up the canvas as a drop target
    const canvas = document.getElementById('appCanvas');
    canvas.addEventListener('dragover', handleDragOver);
    canvas.addEventListener('drop', handleDrop);
    canvas.addEventListener('dragenter', handleDragEnter);
    canvas.addEventListener('dragleave', handleDragLeave);
    
    // Enable component selection on the canvas
    canvas.addEventListener('click', handleCanvasClick);
}

// Drag and Drop Event Handlers
function handleDragStart(e) {
    // Store the component type being dragged
    e.dataTransfer.setData('component', e.target.dataset.component);
    e.dataTransfer.effectAllowed = 'copy';
}

function handleDragOver(e) {
    // Allow dropping
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
}

function handleDragEnter(e) {
    // Highlight drop area
    if (e.target.classList.contains('canvas-component') || 
        e.target.id === 'appCanvas') {
        e.target.classList.add('drag-over');
    }
}

function handleDragLeave(e) {
    // Remove highlight
    if (e.target.classList.contains('drag-over')) {
        e.target.classList.remove('drag-over');
    }
}

function handleDrop(e) {
    e.preventDefault();
    
    // Get the component type
    const componentType = e.dataTransfer.getData('component');
    
    // Remove all drag-over highlights
    document.querySelectorAll('.drag-over').forEach(el => {
        el.classList.remove('drag-over');
    });
    
    // Determine drop target
    let dropTarget = e.target;
    
    // If we're dropping on the canvas itself and it has the placeholder
    if (dropTarget.id === 'appCanvas' && dropTarget.querySelector('.canvas-placeholder')) {
        // Remove placeholder
        dropTarget.innerHTML = '';
    }
    
    // Create the component
    const newComponent = createComponent(componentType);
    
    // Handle container-specific drops
    if (dropTarget.classList.contains('canvas-container-component')) {
        // Drop inside a container
        dropTarget.appendChild(newComponent);
    } else if (dropTarget.id === 'appCanvas') {
        // Drop directly on canvas
        dropTarget.appendChild(newComponent);
    } else if (dropTarget.closest('.canvas-component')) {
        // Drop near another component
        const closestComponent = dropTarget.closest('.canvas-component');
        closestComponent.parentNode.insertBefore(newComponent, closestComponent.nextSibling);
    }
    
    // Update the component IDs to ensure they're unique
    const componentId = 'component_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    newComponent.id = componentId;
    
    // Add to project data structure
    addComponentToCurrentScreen(componentType, componentId);
    
    // Select the new component
    selectComponent(newComponent);
    
    // Initialize any event handlers for the new component
    initializeComponentEventHandlers(newComponent);
}

// Component Creation
function createComponent(type) {
    const component = document.createElement('div');
    component.classList.add('canvas-component', `canvas-${type}-component`);
    component.dataset.componentType = type;
    
    // Create component handle for dragging/selecting
    const handle = document.createElement('div');
    handle.classList.add('component-handle');
    handle.textContent = type.charAt(0).toUpperCase() + type.slice(1);
    component.appendChild(handle);
    
    // Add component-specific content
    switch (type) {
        case 'container':
            component.innerHTML += `<div class="component-content">Container</div>`;
            break;
        case 'row':
            component.innerHTML += `<div class="component-content">Row</div>`;
            break;
        case 'button':
            component.innerHTML += `<div class="component-content">Button</div>`;
            break;
        case 'text':
            component.innerHTML += `<div class="component-content">Text Content</div>`;
            break;
        case 'image':
            component.innerHTML += `
                <div class="component-content image-placeholder">
                    <i data-feather="image"></i>
                    <p>Image</p>
                </div>
            `;
            break;
        case 'input':
            component.innerHTML += `<input type="text" class="component-content" placeholder="Input field">`;
            break;
        case 'list':
            component.innerHTML += `
                <div class="component-content">
                    <div class="canvas-list-item">List Item 1</div>
                    <div class="canvas-list-item">List Item 2</div>
                    <div class="canvas-list-item">List Item 3</div>
                </div>
            `;
            break;
        case 'navigation':
            component.innerHTML += `
                <div class="component-content">
                    <div class="canvas-nav-item">Home</div>
                    <div class="canvas-nav-item">About</div>
                    <div class="canvas-nav-item">Contact</div>
                </div>
            `;
            break;
        case 'webview':
            component.innerHTML += `
                <div class="component-content">
                    <p>Web View Component</p>
                    <p class="text-muted">URL will be displayed here</p>
                </div>
            `;
            break;
        default:
            component.innerHTML += `<div class="component-content">Component Content</div>`;
    }
    
    // Initialize Feather icons
    setTimeout(() => {
        if (window.feather) {
            feather.replace();
        }
    }, 0);
    
    return component;
}

// Initialize event handlers for a newly created component
function initializeComponentEventHandlers(component) {
    // Make the component draggable for repositioning
    component.setAttribute('draggable', 'true');
    component.addEventListener('dragstart', function(e) {
        e.dataTransfer.setData('text/plain', component.id);
        e.dataTransfer.effectAllowed = 'move';
    });
}

// Component Selection
function handleCanvasClick(e) {
    // If clicking on a component or its children
    const closestComponent = e.target.closest('.canvas-component');
    if (closestComponent) {
        selectComponent(closestComponent);
    } else {
        // Clicked on the canvas itself, not a component
        clearComponentSelection();
    }
}

function selectComponent(component) {
    // Clear previous selection
    clearComponentSelection();
    
    // Add selected class to this component
    component.classList.add('selected');
    
    // Store the selected element globally
    selectedElement = component;
    
    // Enable delete button
    document.getElementById('deleteElementBtn').disabled = false;
    
    // Show property controls
    showPropertyControls(component);
}

function clearComponentSelection() {
    // Remove selected class from all components
    document.querySelectorAll('.canvas-component.selected').forEach(el => {
        el.classList.remove('selected');
    });
    
    // Clear global selected element
    selectedElement = null;
    
    // Disable delete button
    document.getElementById('deleteElementBtn').disabled = true;
    
    // Hide property controls
    hidePropertyControls();
}

// Property Panel Functions
function showPropertyControls(component) {
    const propertyControls = document.getElementById('propertyControls');
    const noSelectionMessage = document.getElementById('noSelectionMessage');
    
    // Hide no selection message
    noSelectionMessage.classList.add('d-none');
    
    // Show property controls
    propertyControls.classList.remove('d-none');
    
    // Get component type
    const componentType = component.dataset.componentType;
    
    // Generate property controls based on the component type
    propertyControls.innerHTML = generatePropertyControls(componentType, component);
    
    // Initialize event handlers for property controls
    initializePropertyControlEvents(component);
}

function hidePropertyControls() {
    const propertyControls = document.getElementById('propertyControls');
    const noSelectionMessage = document.getElementById('noSelectionMessage');
    
    // Show no selection message
    noSelectionMessage.classList.remove('d-none');
    
    // Hide property controls
    propertyControls.classList.add('d-none');
}

function generatePropertyControls(type, component) {
    let controls = '';
    
    // Common properties for all components
    controls += `
        <div class="mb-3">
            <label class="form-label">Component Type</label>
            <input type="text" class="form-control" value="${type}" readonly>
        </div>
    `;
    
    // Type-specific properties
    switch (type) {
        case 'container':
            controls += generateContainerControls(component);
            break;
        case 'button':
            controls += generateButtonControls(component);
            break;
        case 'text':
            controls += generateTextControls(component);
            break;
        case 'image':
            controls += generateImageControls(component);
            break;
        case 'input':
            controls += generateInputControls(component);
            break;
        case 'list':
            controls += generateListControls(component);
            break;
        case 'navigation':
            controls += generateNavigationControls(component);
            break;
        case 'webview':
            controls += generateWebViewControls(component);
            break;
        default:
            controls += `
                <div class="alert alert-info">
                    Basic properties available for this component type.
                </div>
            `;
    }
    
    // Common styling properties
    controls += `
        <div class="mb-3">
            <label class="form-label">Styling</label>
            <div class="row g-2">
                <div class="col-6">
                    <label class="form-label small">Width</label>
                    <select class="form-select form-select-sm" id="propWidth">
                        <option value="">Default</option>
                        <option value="100%">Full width</option>
                        <option value="75%">75%</option>
                        <option value="50%">50%</option>
                        <option value="25%">25%</option>
                    </select>
                </div>
                <div class="col-6">
                    <label class="form-label small">Height</label>
                    <input type="text" class="form-control form-control-sm" id="propHeight" placeholder="Auto">
                </div>
            </div>
        </div>
        <div class="mb-3">
            <div class="row g-2">
                <div class="col-6">
                    <label class="form-label small">Margin</label>
                    <input type="text" class="form-control form-control-sm" id="propMargin" placeholder="0px">
                </div>
                <div class="col-6">
                    <label class="form-label small">Padding</label>
                    <input type="text" class="form-control form-control-sm" id="propPadding" placeholder="0px">
                </div>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label small">Background Color</label>
            <input type="color" class="form-control form-control-color" id="propBgColor" value="#ffffff">
        </div>
    `;
    
    return controls;
}

function generateContainerControls(component) {
    return `
        <div class="mb-3">
            <label class="form-label">Layout</label>
            <select class="form-select" id="propContainerLayout">
                <option value="vertical">Vertical</option>
                <option value="horizontal">Horizontal</option>
            </select>
        </div>
    `;
}

function generateButtonControls(component) {
    const buttonContent = component.querySelector('.component-content')?.textContent || 'Button';
    
    return `
        <div class="mb-3">
            <label class="form-label">Button Text</label>
            <input type="text" class="form-control" id="propButtonText" value="${buttonContent}">
        </div>
        <div class="mb-3">
            <label class="form-label">Action</label>
            <select class="form-select" id="propButtonAction">
                <option value="none">None</option>
                <option value="openScreen">Open Screen</option>
                <option value="link">Open Link</option>
                <option value="call">Make Call</option>
                <option value="email">Send Email</option>
            </select>
        </div>
        <div class="mb-3" id="propButtonActionValue" style="display: none;">
            <label class="form-label">Action Value</label>
            <input type="text" class="form-control" id="propButtonActionValueInput">
        </div>
        <div class="mb-3">
            <label class="form-label">Button Color</label>
            <input type="color" class="form-control form-control-color" id="propButtonColor" value="#4285f4">
        </div>
        <div class="mb-3">
            <label class="form-label">Text Color</label>
            <input type="color" class="form-control form-control-color" id="propButtonTextColor" value="#ffffff">
        </div>
    `;
}

function generateTextControls(component) {
    const textContent = component.querySelector('.component-content')?.textContent || 'Text Content';
    
    return `
        <div class="mb-3">
            <label class="form-label">Text Content</label>
            <textarea class="form-control" id="propTextContent" rows="3">${textContent}</textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Text Size</label>
            <select class="form-select" id="propTextSize">
                <option value="12px">Small</option>
                <option value="16px" selected>Normal</option>
                <option value="20px">Large</option>
                <option value="24px">Extra Large</option>
                <option value="32px">Huge</option>
            </select>
        </div>
        <div class="mb-3">
            <div class="row">
                <div class="col-6">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="propTextBold">
                        <label class="form-check-label" for="propTextBold">
                            Bold
                        </label>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="propTextItalic">
                        <label class="form-check-label" for="propTextItalic">
                            Italic
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label">Alignment</label>
            <div class="btn-group w-100">
                <button type="button" class="btn btn-outline-secondary" id="propTextAlignLeft">
                    <i data-feather="align-left"></i>
                </button>
                <button type="button" class="btn btn-outline-secondary" id="propTextAlignCenter">
                    <i data-feather="align-center"></i>
                </button>
                <button type="button" class="btn btn-outline-secondary" id="propTextAlignRight">
                    <i data-feather="align-right"></i>
                </button>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label">Text Color</label>
            <input type="color" class="form-control form-control-color" id="propTextColor" value="#000000">
        </div>
    `;
}

function generateImageControls(component) {
    return `
        <div class="mb-3">
            <label class="form-label">Image Source</label>
            <div class="input-group">
                <input type="text" class="form-control" id="propImageUrl" placeholder="Enter image URL">
                <button class="btn btn-outline-secondary" type="button" id="propImageBrowse">Browse</button>
            </div>
            <small class="text-muted">Use a URL or browse for an image</small>
        </div>
        <div class="mb-3">
            <label class="form-label">Size</label>
            <select class="form-select" id="propImageSize">
                <option value="contain">Original size</option>
                <option value="cover">Cover container</option>
                <option value="100% auto">Full width</option>
                <option value="auto 100%">Full height</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Alt Text</label>
            <input type="text" class="form-control" id="propImageAlt" placeholder="Image description">
            <small class="text-muted">Important for accessibility</small>
        </div>
    `;
}

function generateInputControls(component) {
    return `
        <div class="mb-3">
            <label class="form-label">Input Type</label>
            <select class="form-select" id="propInputType">
                <option value="text">Text</option>
                <option value="email">Email</option>
                <option value="password">Password</option>
                <option value="number">Number</option>
                <option value="tel">Phone</option>
                <option value="date">Date</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Placeholder</label>
            <input type="text" class="form-control" id="propInputPlaceholder" placeholder="Enter placeholder text">
        </div>
        <div class="mb-3">
            <label class="form-label">Label</label>
            <input type="text" class="form-control" id="propInputLabel" placeholder="Input label">
        </div>
        <div class="mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="propInputRequired">
                <label class="form-check-label" for="propInputRequired">
                    Required field
                </label>
            </div>
        </div>
    `;
}

function generateListControls(component) {
    return `
        <div class="mb-3">
            <label class="form-label">List Items</label>
            <div id="listItemsContainer">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" placeholder="List item 1">
                    <button class="btn btn-outline-danger" type="button">
                        <i data-feather="trash-2"></i>
                    </button>
                </div>
                <div class="input-group mb-2">
                    <input type="text" class="form-control" placeholder="List item 2">
                    <button class="btn btn-outline-danger" type="button">
                        <i data-feather="trash-2"></i>
                    </button>
                </div>
                <div class="input-group mb-2">
                    <input type="text" class="form-control" placeholder="List item 3">
                    <button class="btn btn-outline-danger" type="button">
                        <i data-feather="trash-2"></i>
                    </button>
                </div>
            </div>
            <button class="btn btn-sm btn-outline-secondary mt-2" id="addListItemBtn">
                <i data-feather="plus"></i> Add Item
            </button>
        </div>
        <div class="mb-3">
            <label class="form-label">List Style</label>
            <select class="form-select" id="propListStyle">
                <option value="basic">Basic</option>
                <option value="dividers">With Dividers</option>
                <option value="cards">Card Style</option>
            </select>
        </div>
    `;
}

function generateNavigationControls(component) {
    return `
        <div class="mb-3">
            <label class="form-label">Navigation Type</label>
            <select class="form-select" id="propNavType">
                <option value="tabs">Tabs</option>
                <option value="drawer">Drawer/Sidebar</option>
                <option value="bottom">Bottom Navigation</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Navigation Items</label>
            <div id="navItemsContainer">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" placeholder="Home">
                    <select class="form-select" style="max-width: 120px;">
                        <option value="">Select Screen</option>
                        <option value="mainScreen">Main Screen</option>
                    </select>
                    <button class="btn btn-outline-danger" type="button">
                        <i data-feather="trash-2"></i>
                    </button>
                </div>
                <div class="input-group mb-2">
                    <input type="text" class="form-control" placeholder="About">
                    <select class="form-select" style="max-width: 120px;">
                        <option value="">Select Screen</option>
                        <option value="mainScreen">Main Screen</option>
                    </select>
                    <button class="btn btn-outline-danger" type="button">
                        <i data-feather="trash-2"></i>
                    </button>
                </div>
            </div>
            <button class="btn btn-sm btn-outline-secondary mt-2" id="addNavItemBtn">
                <i data-feather="plus"></i> Add Item
            </button>
        </div>
    `;
}

function generateWebViewControls(component) {
    return `
        <div class="mb-3">
            <label class="form-label">URL</label>
            <input type="url" class="form-control" id="propWebViewUrl" placeholder="https://example.com">
        </div>
        <div class="mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="propWebViewScroll">
                <label class="form-check-label" for="propWebViewScroll">
                    Enable scrolling
                </label>
            </div>
        </div>
        <div class="mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="propWebViewZoom">
                <label class="form-check-label" for="propWebViewZoom">
                    Enable zooming
                </label>
            </div>
        </div>
    `;
}

function initializePropertyControlEvents(component) {
    // Initialize Feather icons in property controls
    if (window.feather) {
        feather.replace();
    }
    
    // Handle component type-specific control events
    const componentType = component.dataset.componentType;
    
    // Set up event handlers based on component type
    switch (componentType) {
        case 'button':
            initButtonControlEvents(component);
            break;
        case 'text':
            initTextControlEvents(component);
            break;
        // Add other component types as needed
    }
    
    // Set up common property control events
    initCommonControlEvents(component);
    
    // Set up delete button event handler
    document.getElementById('deleteElementBtn').onclick = function() {
        if (selectedElement) {
            deleteComponent(selectedElement);
        }
    };
}

function initButtonControlEvents(component) {
    // Button text change
    const textInput = document.getElementById('propButtonText');
    if (textInput) {
        textInput.addEventListener('input', function(e) {
            const content = component.querySelector('.component-content');
            if (content) {
                content.textContent = e.target.value;
                updateComponentInDataStructure(component.id, 'content', e.target.value);
            }
        });
    }
    
    // Button action change
    const actionSelect = document.getElementById('propButtonAction');
    const actionValueDiv = document.getElementById('propButtonActionValue');
    
    if (actionSelect) {
        actionSelect.addEventListener('change', function(e) {
            if (e.target.value !== 'none') {
                actionValueDiv.style.display = 'block';
                // Update label based on action type
                const label = actionValueDiv.querySelector('.form-label');
                switch (e.target.value) {
                    case 'openScreen':
                        label.textContent = 'Select Screen';
                        break;
                    case 'link':
                        label.textContent = 'Enter URL';
                        break;
                    case 'call':
                        label.textContent = 'Enter Phone Number';
                        break;
                    case 'email':
                        label.textContent = 'Enter Email Address';
                        break;
                }
                updateComponentInDataStructure(component.id, 'action', e.target.value);
            } else {
                actionValueDiv.style.display = 'none';
                updateComponentInDataStructure(component.id, 'action', null);
            }
        });
    }
    
    // Button colors
    const btnColorInput = document.getElementById('propButtonColor');
    if (btnColorInput) {
        btnColorInput.addEventListener('input', function(e) {
            component.style.backgroundColor = e.target.value;
            updateComponentInDataStructure(component.id, 'backgroundColor', e.target.value);
        });
    }
    
    const btnTextColorInput = document.getElementById('propButtonTextColor');
    if (btnTextColorInput) {
        btnTextColorInput.addEventListener('input', function(e) {
            component.style.color = e.target.value;
            updateComponentInDataStructure(component.id, 'color', e.target.value);
        });
    }
}

function initTextControlEvents(component) {
    // Text content change
    const contentTextarea = document.getElementById('propTextContent');
    if (contentTextarea) {
        contentTextarea.addEventListener('input', function(e) {
            const content = component.querySelector('.component-content');
            if (content) {
                content.textContent = e.target.value;
                updateComponentInDataStructure(component.id, 'content', e.target.value);
            }
        });
    }
    
    // Text size change
    const sizeSelect = document.getElementById('propTextSize');
    if (sizeSelect) {
        sizeSelect.addEventListener('change', function(e) {
            component.style.fontSize = e.target.value;
            updateComponentInDataStructure(component.id, 'fontSize', e.target.value);
        });
    }
    
    // Text style changes
    const boldCheck = document.getElementById('propTextBold');
    if (boldCheck) {
        boldCheck.addEventListener('change', function(e) {
            component.style.fontWeight = e.target.checked ? 'bold' : 'normal';
            updateComponentInDataStructure(component.id, 'fontWeight', e.target.checked ? 'bold' : 'normal');
        });
    }
    
    const italicCheck = document.getElementById('propTextItalic');
    if (italicCheck) {
        italicCheck.addEventListener('change', function(e) {
            component.style.fontStyle = e.target.checked ? 'italic' : 'normal';
            updateComponentInDataStructure(component.id, 'fontStyle', e.target.checked ? 'italic' : 'normal');
        });
    }
    
    // Text alignment
    document.getElementById('propTextAlignLeft')?.addEventListener('click', function() {
        component.style.textAlign = 'left';
        updateComponentInDataStructure(component.id, 'textAlign', 'left');
    });
    
    document.getElementById('propTextAlignCenter')?.addEventListener('click', function() {
        component.style.textAlign = 'center';
        updateComponentInDataStructure(component.id, 'textAlign', 'center');
    });
    
    document.getElementById('propTextAlignRight')?.addEventListener('click', function() {
        component.style.textAlign = 'right';
        updateComponentInDataStructure(component.id, 'textAlign', 'right');
    });
    
    // Text color
    const colorInput = document.getElementById('propTextColor');
    if (colorInput) {
        colorInput.addEventListener('input', function(e) {
            component.style.color = e.target.value;
            updateComponentInDataStructure(component.id, 'color', e.target.value);
        });
    }
}

function initCommonControlEvents(component) {
    // Width change
    const widthSelect = document.getElementById('propWidth');
    if (widthSelect) {
        widthSelect.value = component.style.width || '';
        widthSelect.addEventListener('change', function(e) {
            component.style.width = e.target.value;
            updateComponentInDataStructure(component.id, 'width', e.target.value);
        });
    }
    
    // Height change
    const heightInput = document.getElementById('propHeight');
    if (heightInput) {
        heightInput.value = component.style.height || '';
        heightInput.addEventListener('input', function(e) {
            component.style.height = e.target.value;
            updateComponentInDataStructure(component.id, 'height', e.target.value);
        });
    }
    
    // Margin change
    const marginInput = document.getElementById('propMargin');
    if (marginInput) {
        marginInput.value = component.style.margin || '';
        marginInput.addEventListener('input', function(e) {
            component.style.margin = e.target.value;
            updateComponentInDataStructure(component.id, 'margin', e.target.value);
        });
    }
    
    // Padding change
    const paddingInput = document.getElementById('propPadding');
    if (paddingInput) {
        paddingInput.value = component.style.padding || '';
        paddingInput.addEventListener('input', function(e) {
            component.style.padding = e.target.value;
            updateComponentInDataStructure(component.id, 'padding', e.target.value);
        });
    }
    
    // Background color
    const bgColorInput = document.getElementById('propBgColor');
    if (bgColorInput) {
        bgColorInput.value = rgbToHex(component.style.backgroundColor) || '#ffffff';
        bgColorInput.addEventListener('input', function(e) {
            component.style.backgroundColor = e.target.value;
            updateComponentInDataStructure(component.id, 'backgroundColor', e.target.value);
        });
    }
}

// Component Manipulation
function deleteComponent(component) {
    if (confirm('Are you sure you want to delete this component?')) {
        // Remove from the DOM
        component.remove();
        
        // Remove from data structure
        removeComponentFromDataStructure(component.id);
        
        // Clear selection
        clearComponentSelection();
        
        // If the canvas is empty, add the placeholder back
        const canvas = document.getElementById('appCanvas');
        if (!canvas.hasChildNodes()) {
            canvas.innerHTML = `
                <div class="canvas-placeholder">
                    <p>Drag and drop components here to start building your app</p>
                </div>
            `;
        }
    }
}

// Data Structure Management
function addComponentToCurrentScreen(type, id) {
    if (currentProject && currentScreen) {
        // Create a component data object
        const componentData = {
            id: id,
            type: type,
            properties: {},
            children: []
        };
        
        // Add to the current screen's components
        if (!currentProject.screens[currentScreen].components) {
            currentProject.screens[currentScreen].components = [];
        }
        
        currentProject.screens[currentScreen].components.push(componentData);
        
        // Save the project
        saveProject(currentProject);
    }
}

function updateComponentInDataStructure(id, property, value) {
    if (currentProject && currentScreen) {
        const components = currentProject.screens[currentScreen].components;
        if (components) {
            const component = findComponentById(components, id);
            if (component) {
                if (!component.properties) {
                    component.properties = {};
                }
                component.properties[property] = value;
                
                // Save the project
                saveProject(currentProject);
            }
        }
    }
}

function removeComponentFromDataStructure(id) {
    if (currentProject && currentScreen) {
        const components = currentProject.screens[currentScreen].components;
        if (components) {
            // Find and remove the component
            for (let i = 0; i < components.length; i++) {
                if (components[i].id === id) {
                    components.splice(i, 1);
                    break;
                }
            }
            
            // Save the project
            saveProject(currentProject);
        }
    }
}

function findComponentById(components, id) {
    for (let component of components) {
        if (component.id === id) {
            return component;
        }
        if (component.children) {
            const found = findComponentById(component.children, id);
            if (found) {
                return found;
            }
        }
    }
    return null;
}

// Utility Functions
function rgbToHex(rgb) {
    // If rgb is already a hex color or not defined, return it as is
    if (!rgb || rgb.startsWith('#')) {
        return rgb;
    }
    
    // Convert rgb(r, g, b) to #rrggbb
    const rgbMatch = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    if (rgbMatch) {
        const r = parseInt(rgbMatch[1]).toString(16).padStart(2, '0');
        const g = parseInt(rgbMatch[2]).toString(16).padStart(2, '0');
        const b = parseInt(rgbMatch[3]).toString(16).padStart(2, '0');
        return `#${r}${g}${b}`;
    }
    
    return '#ffffff'; // Default
}

// Debug Function
function logCanvasState() {
    console.log('Current Canvas State:', currentProject?.screens[currentScreen]);
}
