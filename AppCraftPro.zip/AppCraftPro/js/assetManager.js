/**
 * Asset Manager functionality for ZeroApp Builder
 * Manages images, icons, and fonts for app projects
 */

// Track all assets by type
let assets = {
    images: {},
    icons: {},
    fonts: {}
};

/**
 * Initialize the asset manager
 */
function initializeAssetManager() {
    setupAssetButtons();
    loadAssets();
    setupAssetDragDrop();
}

/**
 * Setup event listeners for asset manager buttons
 */
function setupAssetButtons() {
    // Upload asset button
    document.getElementById('uploadAssetBtn').addEventListener('click', function() {
        // Create a hidden file input
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'image/*,.ttf,.otf,.woff,.woff2';
        fileInput.style.display = 'none';
        document.body.appendChild(fileInput);
        
        // Trigger click to open file dialog
        fileInput.click();
        
        // Handle file selection
        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                handleAssetUpload(this.files[0]);
            }
            // Remove the input element
            document.body.removeChild(fileInput);
        });
    });
    
    // Add 'Upload Image' and 'Upload Icon' buttons
    document.querySelectorAll('#imageAssets .empty-state button, #iconAssets .empty-state button').forEach(btn => {
        btn.addEventListener('click', function() {
            // Determine asset type from parent container
            const assetType = this.closest('.asset-grid').id === 'imageAssets' ? 'image/*' : 'image/*';
            
            // Create a hidden file input
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = assetType;
            fileInput.style.display = 'none';
            document.body.appendChild(fileInput);
            
            // Trigger click to open file dialog
            fileInput.click();
            
            // Handle file selection
            fileInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    handleAssetUpload(this.files[0]);
                }
                // Remove the input element
                document.body.removeChild(fileInput);
            });
        });
    });
    
    // Add Font button
    document.querySelector('#fontAssets .empty-state button').addEventListener('click', function() {
        // Create a hidden file input
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.ttf,.otf,.woff,.woff2';
        fileInput.style.display = 'none';
        document.body.appendChild(fileInput);
        
        // Trigger click to open file dialog
        fileInput.click();
        
        // Handle file selection
        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                handleAssetUpload(this.files[0]);
            }
            // Remove the input element
            document.body.removeChild(fileInput);
        });
    });
}

/**
 * Load assets from storage and render in UI
 */
function loadAssets() {
    // For demo purposes, we'll add some sample assets if none exist
    if (Object.keys(assets.images).length === 0) {
        assets.images = {
            'sample_bg.jpg': {
                name: 'sample_bg.jpg',
                type: 'image/jpeg',
                src: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2ODApLCBxdWFsaXR5ID0gOTAK/9sAQwADAgIDAgIDAwMDBAMDBAUIBQUEBAUKBwcGCAwKDAwLCgsLDQ4SEA0OEQ4LCxAWEBETFBUVFQwPFxgWFBgSFBUU/9sAQwEDBAQFBAUJBQUJFA0LDRQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQU/8AAEQgAKAA8AwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A/SoUueKQUlxcw2cLTXEyQxKMs7sFA/E0DJM0w3MasFaRVJ6bjjNcbq/xZ8L6VdPby6qkkyHDJCjSFT6HaP61Qf4yeFUQsL+VgBnCW8pP6LUOpGO7sbRw9WXwxbO9BoJ4NfM3jD9pLTrS4it/DdnLdsDgyTHyo1+nBJP4Cj4d/Hu68TeK7LQ9Q0eCJrtvLSeBmO1sDOQSOh9frWcK9OU+W5tVyzEU4c9j6FF1CZAyTRlT0IcdaUXkBHEq/wDfVc94s8Wad4N0WfVdWnMNrEPqzHsqjux9BXz1rP7V1xNdSHTtEtktycK1w5kYD3AAX9azqVoU9GzajgK9Zc0Uj6q+3QKQDK ......'
            }
        };
    }
    
    if (Object.keys(assets.icons).length === 0) {
        assets.icons = {
            'app_icon.png': {
                name: 'app_icon.png',
                type: 'image/png',
                src: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAEYklEQVR4nO2ZXYgbZRTHf7NJarW6H2m7tlbXdlvXtlLrKliLdL0QEaS1XogfINqCF4JUvVERQa9UEFHpjVd64Y1fIF6oiIpoEVTUVtdutxattY2tdm3dbneTGL7mrXlnMs0kM8kECv3DsMw5c+ac/zlznvMxsIUtbB5spJy+Q4ETwEAp46fSScItwLvAzCYzqSyMAHvNT8fxAHAEqAHVXCRqHTYBl4Spvgud6EsJX9kkRrYy7PJzYAqYB54HXgU2Au+5zZ0YZbRkEbDKrPG5G93BK0HGdJoAwCdtMzQmxoDXgB+B4eC9K4E3gF+Ac4EDQH9Z7MwK/2zE+JeAl9I6TgHbRf7j9vC3d7HAeKrNAfT2qPxxYGee0TcI8zzwMbCQR7AEdoHZ5l+rUCJiwKMhc8pmAC4HngF+K0EvF+LA08BlWQvuA74Pab6I/8KzYJvlPl+Z48A/4lhqwnBfnA4JM2fAE8A5kQsO5VkN3JfQYRz4ICAPMmbK3I8D+8VnngX+MoQF89/X+NE0zy/ZgG0hfb4Sbg3nVUwfB05lJDpqnrc7C4FqdBb/nv80XCZKGHVrHcYIlDDXMtJvpgnXmkS/hg/RLMrUTZ8RQwBgX0jfmjlmxc1hGWqSmcrALyFpjYUO4ZcwHcId8FjzRgK//4XzwHFgCngI2A1cHZAHv5S5MSxdRWFXSC80GfNODmO84npI2gKT5lsFDgK3AWtTDOnPYOQRk666gO0hfT8x5UQkPBky6Z1F9Alws5MwV4Y8+GXM+rAMFcGVwC/ShT7m9iRQ2vSH9PvZ9NvhGDGVkHG3BuF3HWVMFPwfMo8ngIeBS4r2Zy8JqcJuDut0U4Yx9QJG+9pQ+JI3FdL3Y5L2V8CrwBPhUSo1ckXwPnAMOJW1IXDF0A0lGJOG+81JjAOvhCkYVQsV9fEF4OKkRkHnS9Lp9gy6QEjx0Y8+7UVgXdy0aTfwvvLbGu+Mb5e3VXMPY6LgPeCiuEnT5cD7yt+/JN9PtaLH2KTlwc+A6+KmTZcBHylfP8X9GDwJMQTc4ugGTWbVxZhG+K7OzaJ2SZsuBt5UPsbuY5QUXAe8pCL+BPwObHCT6Qawh+W15Ftga5IFZWN3GQa1i2Hgdl8QqFX0ceJKlQfDiBwlKgR9wKvKz8j9DLM7K+4Unpe4G3jUEXtK+Xg2yeIqA7urUaYKPGT6/mz+7y7C8CjYp/w7BqzNUwVEQU1lYjxJ2SoD+4E3nJtgFXgO/wldLsRR4aScjcHeFBtbwefAXqfdMiOqwLvAI8p2G9vYKh5TZ+H9TrsdYBR4QuXlyiSlKyvGVDh921m4W1gHPK3ye4+zaBO4UfnVA2xvx/gpFW5PO+3eYcGtOWZU7CfBDnW/18mMNVjOwnuStNuEKmqlOGeBCQdG7PVZOHgVS0SvOsf4vx87bkZs4X/AP9QQe8KyjRVbAAAAAElFTkSuQmCC'
            }
        };
    }
    
    if (Object.keys(assets.fonts).length === 0) {
        assets.fonts = {
            'roboto.ttf': {
                name: 'roboto.ttf',
                type: 'font/ttf',
                size: '145 KB'
            }
        };
    }
    
    // Render assets in the UI
    renderAssets();
}

/**
 * Render assets in their respective containers
 */
function renderAssets() {
    // Render images
    renderAssetType('images', document.getElementById('imageAssets'));
    
    // Render icons
    renderAssetType('icons', document.getElementById('iconAssets'));
    
    // Render fonts
    renderFonts();
    
    // Update asset counts
    updateAssetCounts();
}

/**
 * Render a specific type of asset (images or icons)
 */
function renderAssetType(type, container) {
    const assetCollection = assets[type];
    
    // Clear container
    container.innerHTML = '';
    
    // Check if empty
    if (Object.keys(assetCollection).length === 0) {
        const typeName = type.charAt(0).toUpperCase() + type.slice(1);
        container.innerHTML = `
            <div class="empty-state">
                <p class="text-center text-muted">No ${type} uploaded yet</p>
                <button class="btn btn-sm btn-outline-secondary mt-2">Upload ${type === 'images' ? 'Image' : 'Icon'}</button>
            </div>
        `;
        return;
    }
    
    // Add each asset
    Object.values(assetCollection).forEach(asset => {
        const assetItem = document.createElement('div');
        assetItem.className = 'asset-item';
        assetItem.dataset.name = asset.name;
        
        assetItem.innerHTML = `
            <div class="asset-preview">
                <img src="${asset.src}" alt="${asset.name}" style="max-width: 100%; max-height: 100%;">
            </div>
            <div class="asset-name">${asset.name}</div>
        `;
        
        container.appendChild(assetItem);
        
        // Add click handler for asset selection
        assetItem.addEventListener('click', function() {
            selectAsset(type, asset.name);
        });
    });
}

/**
 * Render font assets
 */
function renderFonts() {
    const container = document.getElementById('fontAssets');
    
    // Clear container
    container.innerHTML = '';
    
    // Check if empty
    if (Object.keys(assets.fonts).length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <p class="text-center text-muted">No custom fonts added yet</p>
                <button class="btn btn-sm btn-outline-secondary mt-2">Add Font</button>
            </div>
        `;
        return;
    }
    
    // Add each font
    Object.values(assets.fonts).forEach(font => {
        const fontItem = document.createElement('div');
        fontItem.className = 'asset-list-item';
        fontItem.dataset.name = font.name;
        
        fontItem.innerHTML = `
            <div class="asset-icon me-2">
                <i data-feather="type" style="width: 18px; height: 18px;"></i>
            </div>
            <div class="asset-details flex-grow-1">
                <div class="asset-name">${font.name}</div>
                <div class="asset-meta text-muted small">${font.size}</div>
            </div>
            <button class="btn btn-sm btn-icon" title="Delete">
                <i data-feather="trash-2" style="width: 16px; height: 16px;"></i>
            </button>
        `;
        
        container.appendChild(fontItem);
        
        // Re-initialize feather icons
        feather.replace();
        
        // Add click handler for font selection
        fontItem.addEventListener('click', function(e) {
            // Don't select if clicking the delete button
            if (e.target.closest('button')) return;
            selectAsset('fonts', font.name);
        });
        
        // Add delete handler
        fontItem.querySelector('button').addEventListener('click', function() {
            deleteAsset('fonts', font.name);
        });
    });
}

/**
 * Update asset count displays
 */
function updateAssetCounts() {
    // Update image count
    document.querySelector('#imageAssets').closest('.asset-category').querySelector('.asset-count').textContent = 
        Object.keys(assets.images).length;
    
    // Update icon count
    document.querySelector('#iconAssets').closest('.asset-category').querySelector('.asset-count').textContent = 
        Object.keys(assets.icons).length;
    
    // Update font count
    document.querySelector('#fontAssets').closest('.asset-category').querySelector('.asset-count').textContent = 
        Object.keys(assets.fonts).length;
}

/**
 * Handle asset file upload
 */
function handleAssetUpload(file) {
    const fileName = file.name;
    const fileType = file.type;
    const fileSize = formatFileSize(file.size);
    
    // Determine asset type
    let assetType;
    if (fileType.startsWith('image/')) {
        // If it's small and square, consider it an icon
        if (file.size < 200000) { // Less than 200KB
            const img = new Image();
            img.onload = function() {
                if (Math.abs(img.width - img.height) < 10) { // Roughly square
                    addImageAsset('icons', fileName, fileType, this.src);
                } else {
                    addImageAsset('images', fileName, fileType, this.src);
                }
            };
            
            const reader = new FileReader();
            reader.onload = function(e) {
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
            
            return;
        } else {
            assetType = 'images';
        }
    } else if (fileType.includes('font') || 
              fileName.endsWith('.ttf') || 
              fileName.endsWith('.otf') || 
              fileName.endsWith('.woff') || 
              fileName.endsWith('.woff2')) {
        assetType = 'fonts';
        
        // Add the font
        assets.fonts[fileName] = {
            name: fileName,
            type: fileType || 'font/unknown',
            size: fileSize
        };
        
        // Update the UI
        renderFonts();
        updateAssetCounts();
        
        showNotification(`Font "${fileName}" uploaded successfully`, 'success');
        return;
    } else {
        showNotification('Unsupported file type', 'error');
        return;
    }
    
    // Read image file and add to assets
    const reader = new FileReader();
    reader.onload = function(e) {
        addImageAsset(assetType, fileName, fileType, e.target.result);
    };
    reader.readAsDataURL(file);
}

/**
 * Add an image asset (image or icon)
 */
function addImageAsset(type, name, fileType, src) {
    // Add to assets collection
    assets[type][name] = {
        name: name,
        type: fileType,
        src: src
    };
    
    // Update UI
    renderAssetType(type, document.getElementById(`${type}Assets`));
    updateAssetCounts();
    
    // Show success notification
    const typeName = type === 'images' ? 'Image' : 'Icon';
    showNotification(`${typeName} "${name}" uploaded successfully`, 'success');
}

/**
 * Select an asset
 */
function selectAsset(type, name) {
    // Clear any previous selection
    document.querySelectorAll('.asset-item.selected, .asset-list-item.selected').forEach(el => {
        el.classList.remove('selected');
    });
    
    // Select this asset
    if (type === 'fonts') {
        document.querySelector(`.asset-list-item[data-name="${name}"]`).classList.add('selected');
    } else {
        document.querySelector(`.asset-item[data-name="${name}"]`).classList.add('selected');
    }
    
    // Show notification
    const typeName = type.charAt(0).toUpperCase() + type.slice(1, type.length - 1);
    showNotification(`Selected ${typeName}: ${name}`, 'info');
    
    // In a real implementation, this would update a properties panel or similar
}

/**
 * Delete an asset
 */
function deleteAsset(type, name) {
    // Remove from assets collection
    delete assets[type][name];
    
    // Update UI
    if (type === 'fonts') {
        renderFonts();
    } else {
        renderAssetType(type, document.getElementById(`${type}Assets`));
    }
    
    updateAssetCounts();
    
    // Show success notification
    const typeName = type.charAt(0).toUpperCase() + type.slice(1, type.length - 1);
    showNotification(`${typeName} "${name}" deleted`, 'success');
}

/**
 * Setup drag and drop for asset uploads
 */
function setupAssetDragDrop() {
    const assetsTabs = document.getElementById('assets-tab');
    
    // Highlight effect for drag over
    ['dragenter', 'dragover'].forEach(eventName => {
        assetsTabs.addEventListener(eventName, function(e) {
            e.preventDefault();
            this.classList.add('drag-highlight');
        }, false);
    });
    
    // Remove highlight effect when leaving
    ['dragleave', 'drop'].forEach(eventName => {
        assetsTabs.addEventListener(eventName, function(e) {
            e.preventDefault();
            this.classList.remove('drag-highlight');
        }, false);
    });
    
    // Handle drop event
    assetsTabs.addEventListener('drop', function(e) {
        e.preventDefault();
        
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            Array.from(e.dataTransfer.files).forEach(file => {
                handleAssetUpload(file);
            });
        }
    }, false);
}

/**
 * Format file size to human-readable format
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Export all assets (e.g. for saving)
 */
function exportAssets() {
    return JSON.stringify(assets);
}

/**
 * Import assets from JSON
 */
function importAssets(jsonAssets) {
    try {
        assets = JSON.parse(jsonAssets);
        renderAssets();
        return true;
    } catch (e) {
        console.error('Error importing assets:', e);
        return false;
    }
}

/**
 * Get an asset by name and type
 */
function getAsset(type, name) {
    if (assets[type] && assets[type][name]) {
        return assets[type][name];
    }
    return null;
}

// Add drag highlight style
const dragStyle = document.createElement('style');
dragStyle.textContent = `
    .drag-highlight {
        outline: 2px dashed var(--secondary-color);
        outline-offset: -2px;
        background-color: rgba(52, 133, 228, 0.05);
    }
`;
document.head.appendChild(dragStyle);

// Export the functions for use in other modules
window.assetManager = {
    initialize: initializeAssetManager,
    getAsset: getAsset,
    exportAssets: exportAssets,
    importAssets: importAssets
};